# Review: paper v5d9 delta — run hybrid-rev-r5y8-paper-v5d9-261105 (Muse reviewer)

- Candidate: `91eba80b310ea47a7fb2cd4003a13379d8f4c970` on `paper-v5`, tree `dcbcb57954e1bd2f9fdce3e4ba0c333e38b87fa5` (verified in clone).
- Base: `52b0987a` (v5d8, accepted r5y7). Delta: 2 signed commits (`de64614`, `91eba80`, both `%G? = G`, trailer `Codex gpt-6.1-sol`), 40 files.
- Method: `git clone --shared` of the producer checkout into `.temp/rev-v5d9-clone/`, detached at the candidate head; CPU only; producer checkout untouched. Clone deleted after the review.
- Inputs read in full for the delta: brief `hybrid-c-r21p-v5d9.md`; FACTS blocks (Mac calibration PARTIAL, vLLM attempts + diagnostics 1–3 with correction, stage-1 forecast, KV/state sizes, vLLM cached-delta rows, PRO llama.cpp rows §1a); all changed `.tex`, `arithmetic.json`, `sites.json`, `successors.json`, `custody.json`, `test_paper_v5d9.py`, gaps file, README/CHANGELOG/UNRESOLVED deltas.

## Verdict: ACCEPT

Bound to `91eba80b310ea47a7fb2cd4003a13379d8f4c970`. No blocking findings. Notes N1–N7 below do not block.

## Check 1 — Mac bound text: held

- `08-million.tex` + `90-appendix.tex` + `11-limitations.tex` state: Metal against Metal bit-identical, noise 0, `B(524288)=0`; CUDA against Metal reproduces 1.08298 with mean/max KL 0.000329/0.001754, top-1 64/64; delta690 0.83727, KL 0.000399/0.002281. Every value matches the FACTS table exactly.
- 1.04M: “разность 3.01402 остаётся необъяснённой”, owner cancelled before 1,040,000; pending macro rewritten to the cancelled continuation. No completed-calibration claim anywhere in the delta; the word «прошёл» does not occur in the calibration text (only “без утверждения о прохождении допуска”). Pre-existing «прошёл» occurrences elsewhere (bf16 rehearsal, transport) are untouched by the delta and unrelated.
- Appendix carries the custody details: 6 children, kit 1.6.13-cal, pageouts 597–1385 vs 4096, swapouts 0, host load ~70 (timings not idle). Historical 1.0 refusal and post-hoc 4.0 bound preserved in the successor phrase.
- Custody: every nonblank line of `facts-calibration.md.gz` occurs verbatim in the current `FACTS.md` (reviewer-checked, 18/18 lines).

## Check 2 — vLLM text: held

- Exact mechanics stated in main text and appendix: export 0/112 tensors differ; NumPy codec byte-exact in components and logits; server-prefix append byte-identical to full-server import. The v5d8 append-localisation is removed everywhere; the only remaining “локализацию” sentence says the exact controls exclude it.
- Synthetic-workload refusal under the unchanged gate at local tail 1: mixed KL 0.3286 top-1 51/64; full-server 0.2649 53/64; partition 0.0017 64/64. Matches FACTS diagnostics (review-prompt rounding 0.329/0.265).
- Error not confined to the first positions: remaining 59 mixed positions mean KL 0.320, max 2.23; the earlier positions-5–7 reading named wrong. Tail-434 descriptive row 0.168/0.149/0.0012 present. Mixed-minus-full-server excess stated as ≈0.06 (0.3286−0.2649=0.0637, correct).
- Historical 0.020/0.023 declared incomparable with all four FACTS reasons (tails 356/662 vs 1; depths 8196/32806 vs 22385; hybrid-greedy vs fixed teachers; KL(H‖L) vs KL(L‖H)) plus synthetic prompt.
- One-document natural diagnostic presented as diagnostic, not qualification: Pride and Prejudice, same N-1/depth 22,385/teacher-64/direction; mixed 0.00651 excess 0.00558 top-1 60/64 “удовлетворил неизменному допуску” (excess arithmetic verified: 0.00651−0.00093=0.00558); full-server 0.0085 excess 0.00757 58/64 refused on top-1 only; partition 0.00093 62/64. “Это один документ, диагностическая проверка, без квалификации длинной сессии.” No universal-impossibility claim; llama.cpp same-format route remains the qualified one.
- vLLM long session still unqualified, no passing receipt; pending macro: qualification after the one-document diagnostic under the unchanged quality gate. See note N5 on the “amended natural-text attempt” wording.
- Custody: `facts-vllm.md.gz` 52/52 lines verbatim in current `FACTS.md`, including diagnostics 1–3 and the correction.

## Check 3 — Forecast as committed prediction: held

- Appendix: A 13,084.935 s (3.63 h); C 11,992.112/11,882.400/11,790.457 s (3.33/3.30/3.28 h) at 15/20/28 MB/s, RTT 80 ms; office 11,769.066 s; frozen waits 3353.665 s. Reviewer recomputed hours and the active-time tolerance: ±15% total ⇒ 20.2–21.0% active (paper: ≈±20–21%, correct).
- Framed strictly as commitment: “Прогноз является обязательством модели, без результата запуска”, “полный прогон ещё не выполнен”, ±15% criterion kept with active-time/per-phase errors as primary diagnostics. Second signed numeric commitment before inference still required. `facts-forecast.md.gz` 11/11 lines verbatim in FACTS.

## Check 4 — Traffic per architecture (arithmetic): held

Independent recomputation (`/tmp/rev-v5d9-recompute.py`, oracle = FACTS + lifecycle artifact, not `arithmetic.json`): all values reproduce exactly.

- Scenario disclosed as 100,000 new positions × 4 exchanges, decimal GB/MB, no repeats/framing/preparation, all four offloads assumed (no routing-policy decision), no network measurement. Lifecycle cross-check from the archived session artifact: turns 1–4 inputs are 34002/34799/20230/11807 = 100,838 positions, so the round 100,000 understates exact lifecycle bytes by 0.8% (Qwen exact-lifecycle 3.825 GB vs scenario 3.795 GB) — immaterial and the basis is stated.
- Qwen: 100000×34816 + 4×78446592 = 3,795,386,368 B = 3.795 GB. 34,816 B/token q8_0 and 78,446,592 B bf16 state both trace to FACTS.
- Glimmer: paper correctly refuses the naive slot product. Measured 7.3–9.6 KiB/token (100,000× → 0.748–0.983 GB) already includes the live sliding window and slot data, so it is not a marginal wire coefficient. Geometry decomposition verified against `calc/out/run17/architectures/sliding_geometry.csv` and the archived copy (byte-identical rows): global KV 7072 B/position (=13×544), live window 43,450,368 B (=39×2048×544) per exchange → 100000×7072 + 4×43450368 = 881,001,472 B = 0.881 GB. Slot-ratio consistency: predicted sequence bytes give 9.58 KiB/token at 16k and 7.58 KiB/token at 64k, inside the measured range. Charged as full live window per exchange after fill, explicitly “без измерения данного пути переноса”; the CSV basis itself says “not measured prototype delta transport”, consistent.
- Transfer times at 125/20/5 MB/s: 30.4/189.8/759.1 s (Qwen), 7.0/44.1/176.2 s (Glimmer) — recomputed exact. Ten starts/day: 37.95 vs 8.81 GB (main text ≈38 vs ≈9 per person per day). Metered-vs-unlimited sentence present in main text; architecture (not protocol) named as the driver; layer counts 16+48 vs 39 SWA-2048 + 13 global correct.

## Check 5 — Capacity (estimate): held

- Qwen GPU: FACTS vLLM cached-delta Δ10000 anchors 7144/4598/3130 tok/s at 16/65/131k (PRO 6000, FP8, server-only). Reviewer recomputed the linear interpolations: 5377 @50k, 4264 @80k, 4042 @90k — exact. Rounded chunks 24/35/20/12k are the lifecycle timed inputs 24378/34799/20230/11807 (sum 91,214; shared prefix 9624 counted once, outside the repeated load — disclosed, and the different accounting boundary vs the full-volume traffic figure is stated explicitly). T = 24000/7100+35000/5400+20000/4300+12000/4000 = 17.51 s ≈ 18 s. Exact chunks at interpolated rates give 17.55 s. 86400/18 = 4800/day; 70% → 3360 ≈ 3400; 336–480 people at 10 starts/day (main text 340–480, labelled GPU limit; see N4).
- Conditionality kept: appendix “только к GPU prefill при условии квалификации полного пути, без серверной генерации”; main text repeats that long-session vLLM remains unqualified and the overall bound is the min of compute and transfer, with no measured queue or full time-to-Metal.
- Glimmer GPU from its own llama.cpp PRO rows (FACTS §1a Δ10000: 4221/3712/3126 at 16/50/100k): interpolations 3360.4 @80k, 3184.6 @95k recomputed exact; T = 24.83 s, slow-bound 91000/3000 = 30.33 s ⇒ 25–30 s. vLLM-for-Glimmer unmeasured, stated.
- Egress at 125 MB/s: 10.8×10¹² B/day → Qwen 2846 ≈ 2800/day; Glimmer exact-geometry 12,259; at rounded 0.9 GB 12,000; at conservative 1 GB 10,800 ≈ 11,000. The dev-c correction (11,000 → 12,000 at 0.9 GB) is applied in main text, appendix, README and CHANGELOG, with the 1 GB point kept distinct. Recomputed exact.
- Caveats present: uniform arrivals assumed, real days have peaks, queue distribution unmeasured; subagent contexts often smaller than the 34k median first prompt (owner characteristic, share unmeasured); shared prefix computed once; 10 starts/day is an assumed intensity scenario without observed frequency.

## Check 6 — Style, counts, duplication: held (one README note)

- Reviewer reran the producer counter on the clone at the candidate head: **64 pages, 19,206 main-text words** (02: 1048, 06: 857, 08: 1264), abstracts RU 1662 / EN 1568 characters (abstract files unchanged by the delta). Build log: 0 Overfull boxes.
- Verbatim duplication scan (sentences ≥7 words, all sections, v5d9 vs v5d8 trees): 83 duplicated sentences in both trees, **0 new**. New main-text paragraphs vs new appendix text share **0** common 8-word shingles — the main text is a genuine summary, not a copy. New prose matches house style (bold lead-ins, ё usage, decimal conventions).
- README-only repetition: see N1.

## Check 7 — Gates rerun by the reviewer in the clone: all exit 0

Environment: `PYTHONDONTWRITEBYTECODE=1`, TMPDIR inside the clone, tectonic via `--only-cached` wrapper identical to the producer's. Logs: `.temp/rev-v5d9-logs/` (reviewer workspace).

| Gate | Command | Result |
|---|---|---|
| Engine | `python3 -B -m unittest discover -s calc/tests` | **Ran 813 tests in 1172s, OK** (see TMPDIR note below) |
| Kit | `python3 -B -m unittest discover -s bench/tests` | Ran 24 tests, OK |
| v5d9 contracts | `… discover -s calc/tests -p test_paper_v5d9.py` | Ran 9 tests, OK |
| Checkers | `paper/data/offload_bound.py`, `paper/data/check_ranges.py` | exit 0 |
| Checker self-tests | both with `--self-test` | exit 0 |
| Guards | `publication_v2.py`, `r13_ledger.py`, `check_history_evidence.py`, `public_history_guard.py`, `publication_spacing.py`, `test-release.sh`, `test-release-signatures.sh` | all exit 0 |
| Signatures/whitespace | `git verify-commit HEAD`; `git diff --check 52b0987a..HEAD` | exit 0 |
| PDF | `make pdf` (cache-only tectonic) | exit 0; sha256 `c819aba02c7ce18571e69623b7d8217d0fece57d0b09955ce929e57c2bbebbcb` — **bit-identical to the producer PDF** |
| Manifest | `make manifest` + `sha256sum --check` | exit 0; regenerated manifest identical to the committed one (no diff) |

TMPDIR note (reviewer layout, not a candidate defect): the first engine run with TMPDIR as a sibling of the repo root produced 812 passes + 1 ERROR in `test_run16.test_data_only_replacement_rejects_unrecorded_sweep`: `r16_audit.changed_cells()` calls `current.relative_to(ROOT)` on a `TemporaryDirectory` path, which assumes TMPDIR under ROOT (the producer runs with TMPDIR inside the repo). The isolated test passes in 0.154s with TMPDIR under ROOT, and the full 813 rerun under that layout is OK. Recorded as N7.

Adversarial probes (reviewer-written, in-memory via `offload_bound.missing()`, `/tmp/rev-v5d9-mutants.py`): clean texts give `[]` (positive control). All 10 narrowing mutants caught: egress 12,000→11,000 at 0.9 GB; Metal noise 0→“мал”; calibration-not-completed flipped; vLLM qualified flip (main text); one-document diagnostic promoted to qualification; forecast “without a run result” flipped; full-server KL 0.2649→0.02649; first-positions confinement restored; traffic “no network measurement” flipped; GPU 17.51→9.51 s. Dropping the vLLM `\pending` macro is caught by `pending_gaps()`. Checker class limit (N6): a token-preserving appended contradicting sentence is not seen by the phrase checker — same known limit as prior rounds; the delta prose was read in full and contains no such contradiction.

## Findings

```json
[]
```

No blocking findings (`bypass`/`regression`/`robustness`). Acceptance-criteria rows 1–7 all `held` with the evidence above.

## Notes (non-blocking)

- N1 (README duplication, new): the v5d9 README paragraph states the same claim twice in one sentence — “long sessions remain unqualified, with a one-document natural-text diagnostic measured; the long session remains unqualified” (`README.md:870-871` at the candidate). Paper body unaffected (0 new duplicated sentences). Cosmetic; fix in a later pass.
- N2 (stale pointer, retained paragraph): `UNRESOLVED_QUESTIONS.md:499` still ends the pre-v5d9 paragraph with “Exact macros: paper-v5d8-pending.json.” The new v5d9 section in the same file correctly names `paper-v5d9-pending.json` as the current inventory. No false status results.
- N3 (inherited rounding): “Замороженные ожидания … занимают 26–28%” is copied from FACTS. Recomputed shares: 25.6% (A) to 28.4% (C at 28 MB/s) — both ends round slightly outside the stated band. The load-bearing consequence (±20–21% active) recomputes correctly.
- N4 (combination left to the reader): the main-text “340–480 человек” is derived from the GPU bound only. For Qwen the binding resource in the same paragraph is egress (≈2800/day ⇒ ≈280 people at 10/day). The paragraph does state the overall bound is the min of compute and transfer, so no false claim; a combined people figure is simply not printed.
- N5 (pending-attempt wording): the paper keeps long-session qualification pending “after the one-document diagnostic, under the unchanged quality gate” but nowhere states that the pending attempt amends the workload to natural text. FACTS records no such amendment decision (diagnostic 3 is the natural-text diagnostic; investigation continues to the 2026-11-08 deadline), and the r21p brief did not ask for that forward claim — so the paper asserts nothing unsourced. If an amended natural-text qualification has since been decided outside FACTS, it needs a FACTS entry before the paper can name it.
- N6 (checker class limit): `offload_bound` phrase predicates cannot see a token-preserving appended negation (probe reproduced). Mitigated here by full manual reading of the delta prose and by the omission/narrowing mutants all being caught.
- N7 (test portability, pre-existing): `calc/tests/r16_audit.py` `changed_cells()` assumes `tempfile` directories live under the repo ROOT (`relative_to(ROOT)`). With TMPDIR outside ROOT one engine test errors; under the project's own TMPDIR-inside-repo convention the suite is green. Not introduced by v5d9.

## Reproduction artifacts (reviewer)

- `/tmp/rev-v5d9-recompute.py` — independent traffic/capacity/forecast recomputation (ALL OK).
- `/tmp/rev-v5d9-mutants.py` — 10 narrowing mutants + pending-drop + token-preserving probe.
- `/tmp/rev-v5d9-dup.py` — verbatim-duplication scan (0 new).
- `.temp/rev-v5d9-logs/` — gate logs from the clone (engine2.log = the clean 813 OK run; engine.log = the TMPDIR-layout run kept as evidence for N7).

Head reviewed: `91eba80b310ea47a7fb2cd4003a13379d8f4c970`. Verdict: **ACCEPT**, findings `[]`, notes N1–N7.
