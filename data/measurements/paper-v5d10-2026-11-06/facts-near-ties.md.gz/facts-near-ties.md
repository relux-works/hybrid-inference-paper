- **Why Glimmer's answers change about 4× more often than Qwen's: the near-tie study (dev-d r19, branch `m3-near-ties`
  `cbebab6d`, `tools/hybrid-eval/NEAR-TIES.md`; Muse r7bf ACCEPT, 2026-11-05 ~21:48Z).** The content-flip rule is a
  verified lower bound: its blind spots all undercount, so the complement must not be read as «preserved».
  - **Setup.** Decoding in the RULER runs is greedy (`temperature=0`, fixed seed) and the node only prefills, so random
    sampling plays no part. A same-partition repeat is bit-exact. The differences come from floating-point reduction
    order: a different partition or engine changes the last bits of the logits, and greedy argmax flips at near-ties.
  - **Content flips among changed answers** (a conservative rule; not full semantic equivalence):
    - Glimmer 8k 22/255 (8.63%), 32k 19/225 (8.44%), pooled 41/480 (8.54%);
    - Qwen 8k 0/66, 32k 1/62, 64k 0/60, pooled 1/188 (0.53%).
  - **Reading.**
    - Many first edits are presentation or prose, but content is not always preserved: requested values are lost or
      gained with equal scores, so RULER means stay equal.
    - Glimmer generates about 2× more tokens, so 4× more answer changes do not mean 4× more near-ties per token.
  - **Architecture.**
    - Glimmer 30B is dense: 52 layers, 39 sliding-window-2048 and 13 global (every fourth); Q/KV heads 32/2; head
      dimension 128; vocabulary 202,048; output scale 0.196116 with final-logit softcap 20; no MoE router.
    - Qwen3.8-27B is a dense hybrid: 16 attention and 48 recurrent layers.
    - Softcapping compressing the top-2 margins is a hypothesis, not a result.
    - The GPU margin stage that would test it is written and CPU-tested (dev-d r20 `250f2239`), but it was not run.
      - The original 8k RULER prompts were not preserved: 2 of the 26 Qwen specs survive on node A, and Glimmer's node
        was destroyed.
      - Running it needs either prompts regenerated from the pinned data (lock f42a48cc, seed 261102) with exact
        hash checks, or a new prompt set declared before any run as a separate experiment. Future work.
    - The same near-tie mechanism appears in Qwen on natural text: see vLLM attempt 5, turn 4, where all six top-1
      disagreements sit at top-2 margins of 0.006-0.18 logits.
