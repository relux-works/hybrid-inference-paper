    - **Attempt 5, natural-text amendment** (amendment `fcb61bc6`, runtime `498d6762`, tests-only fix `b1d6798e`;
      Muse r5x16 and r5x17 ACCEPT; node V 2026-11-05 23:37:27Z to 11-06 00:00:02Z; status failed, qualified=false).
      - Workload natural-v1: three pinned public books (pg1342, pg2701, pg2600), each document's own continuation as
        the teacher. Same FP8-Q4-SESSION-KL-1, N-1, teacher-64, KL(local||hybrid).
      - Packet: `attempt5-small.tgz`, sha256 3fbe3361..., 667,954 B, 25 allowlisted files, no clients.json.
      - Turns:

        | Turn | Prompt | Eviction | KL | Excess | Top-1 | Partition KL / top-1 | Verdict |
        |---|---|---|---|---|---|---|---|
        | 1 | 22,385 | | 0.0196 | 0.0164 | 61/64 | 0.0032 / 63 | pass |
        | 2 | 28,417 | | 0.0171 | 0.0135 | 64/64 | 0.0035 / 61 | pass |
        | 3 | 34,449 | forced | 0.0156 | 0.0128 | 63/64 | 0.0028 / 63 | pass |
        | 4 | 40,481 | | 0.0034 | 0.0023 | 58/64 | 0.0011 / 63 | refused, top-1 bound only |

      - The stage stopped at turn 4, as designed, so the session never reached 64k and turns 5-10 did not run.
      - Turn 4 has the smallest KL of the attempt, yet it fails the top-1 bound. All six disagreements are near-ties:
        - the local reference's top-2 logit margins there are 0.006 / 0.031 / 0.041 / 0.107 / 0.109 / 0.179;
        - its top-1 probability there is 0.07-0.51;
        - per-position KL is 0.001-0.014;
        - the hybrid's |Δlogit| is 0.30-0.85.
        - In this text 23 of 64 positions have a top-2 margin under 0.5 logits; the 10% quantile is 0.107.
        - The partition control's one flip has margin 0.031.
        - Source: an orchestrator read-only diagnostic on node V, `attempt5/margins5.py` and `margins5.out` in the
          evidence directory. It reproduces the reported per-position KL to 1e-13.
      - Reading:
        - On natural text the FP8-to-Q4 handoff keeps the distribution close: excess KL 0.002-0.016 through 40k,
          including one forced eviction.
        - The preregistered top-1 bound of 60/64 counts near-tie flips on high-entropy text. It refused even though
          the distribution error was the lowest of the attempt.
        - Under the frozen criterion vLLM in a long session stays unqualified, so the paper says «в работе». A
          top-1 criterion that handles near-ties would need to be fixed in advance, on documents not yet seen.
      - dev-a's conclusion (r42f `b7e2b6d2`): the codec and append controls are exact, but the N-1 handoff fails
        even with an all-server prefix. llama.cpp stays the qualified fallback. No universal impossibility is
        claimed. A natural-text diagnostic is proposed.
      - dev-a r42f is investigating. Without a qualified receipt, the llama.cpp same-format path, where Q8 to Q4 sits
        within partition noise, stays the qualified route.

