  - **Log date coverage, cohort full05.** Codex 2025-11-18..2026-10-30, Claude 2026-05-07..2026-10-28, Muse
    2026-08-06..2026-10-30. The parser accepts October 2025, but the export cannot tell whether October sessions are
    absent, outside the inventory or discarded.
    - **Raw-store census on the owner's Mac** (incident lane, 2026-11-05 22:44Z; file names and mtimes only, no file
      opened):
      - Codex: exactly one rollout predates 2025-11-18 (2025-09-22). There are no October 2025 rollouts in any live
        Codex store, and no file of any kind with an October 2025 mtime in the two backup archives.
        - Unique Codex rollouts by file-name month (9,631): 2025-09 1, 2025-11 127, 2025-12 612, 2026-01 268, 2026-02
          276, 2026-03 304, 2026-04 170, 2026-05 567, 2026-06 53, 2026-07 1,424, 2026-08 1,971, 2026-09 1,376, 2026-10
          2,348, 2026-11 134.
      - Claude: the live stores start on 2026-08-31, later than the cohort's 2026-05-07, so the export holds older
        Claude sessions than the live store.
      - Muse: JSONL files from 2026-08-06; these are files, not a session count.
      - So the October 2025 Codex sessions the owner recalls are not on this Mac. Whether they existed and were removed
        cannot be told.
      - Limits: archive mtimes may not be copy-preserved; the Nov 1 LaCie snapshot copies, the sqlite and history
        files, and the compressed archives were not unpacked or counted per tool.

