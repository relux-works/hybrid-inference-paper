| depth | segment prefill tok/s |  | decode tok/s (at depth) |
|---|---|---|

parallel: 2 streams at 32k: aggregate 42.66 tok/s, single 27.43, gain x1.56
