| depth | segment prefill tok/s | Δ256 prefill tok/s | Δ512 prefill tok/s | decode tok/s (at depth) |
|---|---|---|---|---|
| 2k (cum. 0.0 min) | 1378.3 | 1349.2 | 1301.3 | 38.21 |
| 4k (cum. 0.0 min) | 1350.1 | 1290.5 | 1269.7 | 37.93 |
