| depth | segment prefill tok/s | Δ512 prefill tok/s | Δ2000 prefill tok/s | Δ10000 prefill tok/s | decode tok/s (at depth) |
|---|---|---|---|---|---|
| 16k (cum. 0.2 min) | 1306.5 | 1187.9 | 1137.7 | 1089.4 | 31.51 |
| 50k (cum. 0.6 min) | 938.3 | 852.9 | 811.7 | 805.1 | 24.54 |
| 86k (cum. 1.1 min) | 710.3 | 657.2 | 608.0 | 629.3 | 20.12 |
slot save at 16k: 714 MB = 43.6 KiB/token, 338.458 ms
slot save at 50k: 1899 MB = 37.1 KiB/token, 915.499 ms
slot save at 86k: 3153 MB = 35.8 KiB/token, 1508.899 ms
