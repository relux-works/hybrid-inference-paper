| depth | segment prefill tok/s |  | decode tok/s (at depth) |
|---|---|---|

parallel: 4 streams at 32k: aggregate 62.82 tok/s, single 31.67, gain x1.98
