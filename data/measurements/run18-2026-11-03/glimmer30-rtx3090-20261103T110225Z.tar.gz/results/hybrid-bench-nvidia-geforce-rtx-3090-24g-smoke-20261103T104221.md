| depth | segment prefill tok/s | Δ256 prefill tok/s | Δ512 prefill tok/s | decode tok/s (at depth) |
|---|---|---|---|---|
| 4k (cum. 0.0 min) | 1366.5 | 1258.3 | 1249.2 | 41.66 |
