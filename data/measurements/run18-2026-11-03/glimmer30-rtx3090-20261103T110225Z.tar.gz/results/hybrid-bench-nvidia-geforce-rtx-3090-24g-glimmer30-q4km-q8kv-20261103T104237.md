| depth | segment prefill tok/s | Δ512 prefill tok/s | Δ2000 prefill tok/s | Δ10000 prefill tok/s | decode tok/s (at depth) |
|---|---|---|---|---|---|
| 16k (cum. 0.2 min) | 1329.4 | 1233.8 | 1222.2 | 1212.2 | 35.36 |
| 50k (cum. 0.5 min) | 1122.2 | 1042.9 | 1024.5 | 1027.2 | 30.02 |
| 100k (cum. 1.2 min) | 936.6 | 843.0 | 837.0 | 853.8 | 25.14 |
| 118k (cum. 1.3 min) | 827.4 | 794.0 | 788.2 | 803.4 | 23.86 |
slot save at 16k: 157 MB = 9.6 KiB/token, 84.362 ms
slot save at 50k: 398 MB = 7.8 KiB/token, 206.286 ms
slot save at 100k: 752 MB = 7.3 KiB/token, 523.637 ms
slot save at 118k: 880 MB = 7.3 KiB/token, 442.234 ms
