# Parallel decode at depth 65536: nvidia-geforce-rtx-3090-24g-glimmer30-depth64k

parallel_depth 1.2; model Muse-Glimmer-30B-KQuant-17GB-Q4_K_M.gguf; build b12032-dde879bc4; 128 tokens per stream; 1 rounds.

Server np=8, total context=None, per-slot context=66560; caller cooldown=0s. np 8, ctx 532480, q8_0 KV, fa on

One-time prefill of 65536 tokens: 1132.1 tok/s.

| Streams | Median aggregate tok/s | Every round aggregate tok/s | Median per-stream tok/s | Every round per-stream tok/s | Gain | Valid |
|---:|---:|---|---|---|---:|---|
| 1 | 28.009 | [28.009] | [28.009] | [[28.009]] | 1.0 | True |
| 2 | 41.532 | [41.532] | [20.772, 20.766] | [[20.772, 20.766]] | 1.483 | True |
| 4 | 49.391 | [49.391] | [12.497, 12.348, 12.496, 12.494] | [[12.497, 12.348, 12.496, 12.494]] | 1.763 | True |
| 8 | 56.98 | [56.98] | [7.127, 7.127, 7.126, 7.125, 7.124, 7.124, 7.123, 7.123] | [[7.127, 7.127, 7.126, 7.125, 7.124, 7.124, 7.123, 7.123]] | 2.034 | True |

Aggregate: timed decode steps (predicted_n - 1) summed across streams, divided by the longest server decode interval. Medians require every requested round to be valid and to reuse the restored context; raw invalid rounds remain in JSONL.
