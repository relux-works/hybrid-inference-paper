| depth | segment prefill tok/s |  | decode tok/s (at depth) |
|---|---|---|

parallel: 4 streams at 32k: aggregate 124.02 tok/s, single 62.98, gain x1.97
