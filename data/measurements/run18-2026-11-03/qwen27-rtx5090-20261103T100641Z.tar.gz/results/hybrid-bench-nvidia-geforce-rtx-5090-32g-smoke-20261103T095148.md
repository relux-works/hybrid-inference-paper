| depth | segment prefill tok/s | Δ256 prefill tok/s | Δ512 prefill tok/s | decode tok/s (at depth) |
|---|---|---|---|---|
| 2k (cum. 0.0 min) | 3979.5 | 3549.0 | 3597.4 | 73.98 |
| 4k (cum. 0.0 min) | 3772.9 | 3441.2 | 3497.0 | 73.83 |
