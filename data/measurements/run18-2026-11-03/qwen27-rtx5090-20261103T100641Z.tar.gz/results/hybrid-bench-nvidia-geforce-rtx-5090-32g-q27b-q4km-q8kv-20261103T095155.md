| depth | segment prefill tok/s | Δ512 prefill tok/s | Δ2000 prefill tok/s | Δ10000 prefill tok/s | decode tok/s (at depth) |
|---|---|---|---|---|---|
| 16k (cum. 0.1 min) | 3757.7 | 3650.0 | 3366.4 | 3190.9 | 65.68 |
| 50k (cum. 0.2 min) | 2585.7 | 2326.7 | 2186.0 | 2001.9 | 57.95 |
| 100k (cum. 0.6 min) | 1590.0 | 1368.0 | 1373.2 | 1324.2 | 48.64 |
| 150k (cum. 1.1 min) | 1145.7 | 1013.1 | 1032.5 | 1006.5 | 41.66 |
| 200k (cum. 1.8 min) | 895.2 | 807.8 | 828.7 | 808.2 | 36.43 |
| 249k (cum. 2.6 min) | 738.8 | 667.7 | 692.9 | 680.0 | 32.42 |
slot save at 16k: 714 MB = 43.6 KiB/token, 316.203 ms
slot save at 50k: 1899 MB = 37.1 KiB/token, 519.758 ms
slot save at 100k: 3641 MB = 35.6 KiB/token, 801.337 ms
slot save at 150k: 5383 MB = 35.0 KiB/token, 1148.067 ms
slot save at 200k: 7126 MB = 34.8 KiB/token, 1627.326 ms
slot save at 249k: 8833 MB = 34.6 KiB/token, 2054.961 ms
