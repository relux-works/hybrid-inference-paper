| depth | segment prefill tok/s | Δ512 prefill tok/s | Δ2000 prefill tok/s | Δ10000 prefill tok/s | decode tok/s (at depth) |
|---|---|---|---|---|---|
| 16k (cum. 0.1 min) | 3822.9 | 3841.2 | 3572.8 | 3555.9 | 73.85 |
| 50k (cum. 0.2 min) | 3347.4 | 3297.3 | 3154.6 | 3121.3 | 67.49 |
| 100k (cum. 0.4 min) | 2868.8 | 2689.4 | 2611.9 | 2578.2 | 59.63 |
| 118k (cum. 0.4 min) | 2500.0 | 2490.9 | 2436.4 | 2402.5 | 57.19 |
slot save at 16k: 157 MB = 9.6 KiB/token, 35.467 ms
slot save at 50k: 398 MB = 7.8 KiB/token, 86.391 ms
slot save at 100k: 752 MB = 7.3 KiB/token, 164.111 ms
slot save at 118k: 880 MB = 7.3 KiB/token, 263.371 ms
