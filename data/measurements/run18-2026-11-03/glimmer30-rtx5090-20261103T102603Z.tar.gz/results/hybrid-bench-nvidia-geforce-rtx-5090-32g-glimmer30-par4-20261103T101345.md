| depth | segment prefill tok/s |  | decode tok/s (at depth) |
|---|---|---|

parallel: 4 streams at 32k: aggregate 129.43 tok/s, single 71.47, gain x1.81
