# Parallel decode at depth 65536: nvidia-geforce-rtx-5090-32g-glimmer30-depth64k

parallel_depth 1.2; model Muse-Glimmer-30B-KQuant-17GB-Q4_K_M.gguf; build b12032-dde879bc4; 128 tokens per stream; 1 rounds.

Server np=16, total context=None, per-slot context=66560; caller cooldown=0s. np 16, ctx 1064960, q8_0 KV, fa on

One-time prefill of 65536 tokens: 3385.1 tok/s.

| Streams | Median aggregate tok/s | Every round aggregate tok/s | Median per-stream tok/s | Every round per-stream tok/s | Gain | Valid |
|---:|---:|---|---|---|---:|---|
| 1 | 65.132 | [65.132] | [65.132] | [[65.132]] | 1.0 | True |
| 2 | 92.149 | [92.149] | [46.082, 46.074] | [[46.082, 46.074]] | 1.415 | True |
| 4 | 110.75 | [110.75] | [27.696, 27.693, 27.69, 27.687] | [[27.696, 27.693, 27.69, 27.687]] | 1.7 | True |
| 8 | 211.72 | [211.72] | [26.485, 26.482, 26.478, 26.475, 26.472, 26.469, 26.466, 26.465] | [[26.485, 26.482, 26.478, 26.475, 26.472, 26.469, 26.466, 26.465]] | 3.251 | True |
| 16 | 250.268 | [250.268] | [15.656, 15.654, 15.653, 15.652, 15.651, 15.65, 15.649, 15.648, 15.647, 15.645, 15.644, 15.644, 15.643, 15.643, 15.642, 15.642] | [[15.656, 15.654, 15.653, 15.652, 15.651, 15.65, 15.649, 15.648, 15.647, 15.645, 15.644, 15.644, 15.643, 15.643, 15.642, 15.642]] | 3.842 | True |

Aggregate: timed decode steps (predicted_n - 1) summed across streams, divided by the longest server decode interval. Medians require every requested round to be valid and to reuse the restored context; raw invalid rounds remain in JSONL.
