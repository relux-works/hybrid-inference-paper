| depth | segment prefill tok/s | Δ256 prefill tok/s | Δ512 prefill tok/s | decode tok/s (at depth) |
|---|---|---|---|---|
| 4k (cum. 0.0 min) | 3910.1 | 3526.7 | 3492.1 | 80.88 |
