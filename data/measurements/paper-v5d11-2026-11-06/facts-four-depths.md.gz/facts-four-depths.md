- **RULER for Qwen, the registered four-depth analysis, COMPLETE (dev-d r16e, `m3-ruler-equivalence` `01b49836`, signed;
  frozen tool `e46e5623` unchanged, 48/48 tests; MUSE REVIEW PENDING; 2026-11-06).** Report
  `tools/hybrid-eval/RULER-EQUIVALENCE-RESULTS.md` and `equivalence-results/qwen.json` in `~/Werkstatt/hybrid-d/llama.cpp`;
  handoff `.temp/hybrid-d-r16e-261106/RULER-FOUR-DEPTHS.md` there.
  - **Inputs.** Four depths of 390/390 pairs each, seed 261102, model 31629f53..., lock f42a48cc, source `18d3f114`. All
    archive hashes, every `SHA256SUMS` member and all row hashes verify.
    - The binaries differ across depths at the same commit: 8k and 32k were one build, 64k a fresh build, and 128k node
      B's build. The tool does not compare native binaries across depths. Within each depth, the evaluator's resume
      gate requires the whole manifest to be equal.
  - **Rule.** Holm across the four depths, separately for offload-local and partition-local, α = 0.025, margin ±2 pp.
    The «claim» policy is the post-review supplement accepted at `e46e5623`, before the 64k and 128k data:
    - a degenerate set, or a bootstrap pass with nonzero spread, needs both sidecars (exact unseen range or discordance,
      and score==1 Newcombe);
    - the claim Holm uses the larger sidecar p.

    | Depth | Difference, pp (offload / partition) | 95% interval | Registered Holm p | Claim Holm p | Claim |
    |---:|---|---|---|---|---|
    | 8k | 0 / 0 | [0, 0], degenerate; sidecars ±0.94 and ±1.04 | 0.0004 / 0.0004 | 0.0096 / 0.0096 | equivalent, via the sidecars |
    | 32k | 0 / −0.26 | [−1.05, +1.05] / [−1.47, +0.85], Newcombe | 0.0050 / 0.0073 | 0.0096 / 0.0145 | equivalent |
    | 64k | 0 / 0 | [−1.05, +1.05], Newcombe | 0.0050 / 0.0050 | 0.0096 / 0.0096 | equivalent |
    | 128k | +0.09 / +0.09 | [−0.68, +0.85], bootstrap | 0.0004 / 0.0004 | 0.0482 / 0.0482 | NOT established |

  - **128k.** The registered interval lies well inside ±2 pp. The frozen guard still withholds the claim:
    - three fwe pairs differ by partial credit;
    - the guard's envelope from the first two sorted pairs (cwe) is [0, 0], so the three are departures among the
      remaining 388;
    - the exact unseen-range sidecar is therefore ±2.24 pp, which crosses the margin. The binarised sidecar is
      [−1.05, +1.63] pp, p 0.0106.
    - Report both: the registered arithmetic passes, and the claim is not established under the frozen policy.
  - **Not claimed:**
    - a simultaneous four-depth claim;
    - equal answer text: text equivalence at ±2 pp fails at every depth (changed offload/partition 34/32, 33/29, 28/32,
      32/27 of 390);
    - quality outside RULER.
  - **Scores,** local / offload / partition: 97.01/97.01/97.01% at 8k, 97.44/97.44/97.18% at 32k, 97.18/97.18/97.18% at
    64k, and 95.81/95.90/95.90% at 128k.
  - **Disclosures.**
    - The margin was fixed after Qwen 8k and 32k had been observed.
    - 128k is «straddling, not confirmatory»: its main stage started at 14:29:06Z. The first example's three serial arm
      calls alone take 359.0 s and the second's 359.5 s, against 414 s before 14:36:00Z. So at most one of the 390 rows
      could have been written before the registration; zero or one is not resolved.
    - 64k is «after».
    - At 128k the host changed (B, then A, with B's binaries).
    - Both deep completions came after the original RC4 data cut-off of 2026-11-05 12:00Z.
  - **bf16:** see the next block. The frozen tool refused the archives' arm name `offload_bf16` (exit 2), so r16f added
    a separate input adapter.

