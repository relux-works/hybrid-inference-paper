- **RULER for Qwen, the bf16 state arm, registered analysis at 8k and 32k (dev-d r16f, `m3-ruler-equivalence`
  `779e66a3`, signed; adapter `tools/hybrid-eval/ruler_bf16_adapter.py`; 72/72 tests, 48 old plus 24 new; MUSE REVIEW
  PENDING; 2026-11-06).** Handoff `.temp/hybrid-d-r16f-261106/RULER-BF16.md` in `~/Werkstatt/hybrid-d/llama.cpp`.
  - **The adapter.**
    - It verifies both bf16 archives and their f32 baselines, and maps only `offload_bf16` to `bf16`. It keeps every
      original, derived and baseline row-hash link (`bf16-input-provenance.json`).
    - The statistics, the 48 old tests, and the Qwen f32 and Glimmer outputs are unchanged.
    - Two mutants are killed: the wrong arm, and a skipped baseline check.
  - **Data.** The candidate is `m3-state-bf16` `8d876c71`. Each depth has 390 pairs, seed 261102, lock f42a48cc. All
    780 bf16 scores equal the local and the f32-offload scores.

    | Depth | Pair | Difference, 95% interval (pp) | Registered Holm p | Claim Holm p | Claim |
    |---:|---|---|---|---|---|
    | 8k | bf16-local, bf16-offload | 0, [0, 0] degenerate; sidecars ±0.94 and ±1.04 | 0.0004 | 0.0096 | equivalent via the sidecars |
    | 32k | bf16-local, bf16-offload | 0, [−1.05, +1.05] Newcombe | 0.0077 | 0.0096 | equivalent |

  - **64k and 128k bf16 were never measured.** They enter both four-depth families at p = 1, so the adjusted p are upper
    bounds. The observed claims cannot reverse. Neither family is complete, and nothing is claimed for the missing
    depths.
  - **Timing.**
    - The stage's execute window ran from 14:23:39Z to 18:41:33Z. rc=1 was the restore of the services after the arms
      failed; both arms are complete.
    - The 390 serial 8k calls sum to 3,027 s, more than the 741 s before the registration. So 8k ended after the
      registration, but its start is unknown: «unknown (after or straddling), not confirmatory».
    - 32k ran after the whole 8k arm, so it started no earlier than 15:14:06Z: «after».
  - **Not claimed:** equal answer text, quality outside RULER, or bf16 at the higher depths.

