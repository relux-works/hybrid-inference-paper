# Qwen RULER: four completed depths, hybrid-d-r16e-261106

Prepared on CPU on agents1, 2026-11-06, from accepted m3-ruler-equivalence e46e5623. Frozen statistical tool unchanged; Glimmer unchanged. This report supplements tools/hybrid-eval/RULER-EQUIVALENCE-RESULTS.md and its committed equivalence-results/qwen.json. Original read-only inputs were copied into this run's .temp before use. No inference, downloads, live API calls, service changes or pushes.

## FACTS-ready block (English)

**Qwen paired RULER, completed four-depth score analysis (dev-d r16e, 2026-11-06).** All four depths have 390/390 paired examples (13 tasks x 30), seed 261102, model 31629f53..., input lock f42a48cc..., evaluator/native source 18d3f114. The statistical tool is unchanged from accepted e46e5623. Four-depth Holm is applied separately to offload-local and partition-local at alpha=0.025. No Qwen f32 depth remains pending.

| Depth | Registered Holm p, offload | Registered Holm p, partition | Supplementary claim Holm p, offload | Supplementary claim Holm p, partition | Verdict under the frozen accepted claim policy |
|---:|---:|---:|---:|---:|---|
| 8192 | 0.0004 | 0.0004 | 0.00955311695 | 0.00955311695 | equivalent for both via two sidecars; degenerate primary cannot certify |
| 32768 | 0.0049988767 | 0.0072563175 | 0.00955311695 | 0.014512635 | equivalent for both |
| 65536 | 0.0049988767 | 0.0049988767 | 0.00955311695 | 0.00955311695 | equivalent for both |
| 131072 | 0.0004 | 0.0004 | 0.0482094776 | 0.0482094776 | not established for either; supplementary raw-score guard crosses margin |

- The registered mean-score interval/Holm arithmetic passes for both pairs at every depth. At 8k it is a degenerate [0,0] pp bootstrap, so the equivalence statement instead rests on the post-review exact unseen-discordance [-0.9414,+0.9414] pp and score==1 Newcombe [-1.0387,+1.0387] pp sidecars (maximum sidecar TOST p=0.00238827924). Both pass supplementary four-depth claim Holm, p=0.00955311695.
- At 32k the offload difference is 0.0000 pp, Newcombe 95% [-1.0519,+1.0519], TOST p=0.00255608516; partition is -0.2564 pp, [-1.4704,+0.8517], p=0.00725631750. At 64k both differences are 0.0000 pp, Newcombe [-1.0475,+1.0475], p=0.00249943835. Both depths satisfy the registered and supplementary claim Holm criteria for both arm pairs.
- At 128k both differences are +0.0855 pp, paired-bootstrap 95% [-0.6838,+0.8547], 10000 resamples, seed 261102. Registered TOST p=0.0001 (resolution floor), Holm p=0.0004. This is nondegenerate, but the already accepted r16c bootstrap-pass guard also applies: its exact unseen-range sidecar is [-2.2429,+2.2429] pp, TOST and supplementary claim Holm p=0.0482094776. The binarised sidecar is [-1.0493,+1.6307] pp, p=0.0105640398. Both sidecars are required, so equivalence is withheld for both 128k pairs under the frozen accepted policy. The registered result and the conservative supplement must be reported separately. No near-margin diagnostic triggers.
- RULER scores local/offload/partition are 97.01/97.01/97.01% at 8k; 97.44/97.44/97.18% at 32k; 97.18/97.18/97.18% at 64k; 95.81/95.90/95.90% at 128k. Changed answer counts offload/partition are 34/32, 33/29, 28/32 and 32/27, each out of 390. Text-equivalence at +/-2 pp is not established at any depth. The nonsignificant text/accuracy McNemar tests are not evidence of equivalence.
- Disclosures: the +/-2 pp margin was fixed after observing Qwen 8k/32k; the 128k collection straddled registration (14:29:06Z start against 14:36Z, pilot 14:16:37Z), with at most one archived row possibly written before registration and no exact timestamped count. The 64k collection began after registration. At 128k rows 1-226 ran on node B and rows 227-390 on A with B's exact binaries at the same paths; pairing stayed within host per example. The final 225-row saved prefix and its manifest match the off-node copy. Separate builds across depths have different native binary hashes at the same source commit.
- bf16 was named by the registration, but was never run at 64k/128k. The 8k/32k archives are verified; their fourth-arm name offload_bf16 is rejected by the frozen tool, which expects bf16. No adapter or new statistical code was written, and no bf16 equivalence result is issued. A reviewed provenance-preserving adapter is needed, after which the two absent depths must enter both bf16 families at p=1. No complete bf16-family claim is supported.
- The accepted claim policy establishes the stated RULER score bounds at 8k/32k/64k, not a simultaneous four-depth claim, identical answer text, or quality equivalence outside RULER. Both deep-depth completions are after the original RC4 cut-off (2026-11-05 12:00Z); this is a post-cut-off completion analysis.

## Verified source archives and identity

Every compressed hash was checked before reading its inputs. Every regular member other than SHA256SUMS is covered by SHA256SUMS and verified: six archives, eight members each, 48 internal hashes. All 2340 rows, including the 780 bf16 rows, pass their own row_sha256 checks. Four f32 companion CSVs match their JSONL rows. The small input copies are removed after validation; original inputs are unchanged.

| Input | Original archive | SHA-256 |
|---|---|---|
| qwen-8192 | `/home/agent/lanes/hybrid/.temp/ruler-results-261103/depth-8192-complete.tar.gz` | `2be3eae64b783867258a1f22e1c7bbdb4188f257c378f17c07554a8868248aa4` |
| qwen-32768 | `/home/agent/lanes/hybrid/.temp/ruler-results-261103/depth-32768-complete.tar.gz` | `a6fb1e7e6ac0fb7d25ed3ed24ef1f47cdf4f6495b54a4866d6486870bfeef176` |
| qwen-65536 | `/home/agent/lanes/hybrid/.temp/ruler-results-261106/qwen-inputs/depth-65536-complete.tar.gz` | `012c9308fcd7cc4343deb023ced9f026d9fe26cc6a3e4dd8fdc63ebf75c13fd8` |
| qwen-131072 | `/home/agent/lanes/hybrid/.temp/ruler-results-261106/qwen-inputs/depth-131072-complete.tar.gz` | `36da2f0328ad2145dcab3ed47cc215744708d66b90602b42e0495666baecc94e` |
| bf16-8192 | `/home/agent/lanes/hybrid/.temp/ruler-results-261103/bf16-8d876c71/bf16-8192-complete.tar.gz` | `c0348572c2c1baf50dcfcdd0a73397594ba0d12e45ba157b0ae63980f25799b6` |
| bf16-32768 | `/home/agent/lanes/hybrid/.temp/ruler-results-261103/bf16-8d876c71/bf16-32768-complete.tar.gz` | `5efae77aa8b9902bd31b9b2a1ba336a0d8a090353898fd31fee8c980e73e1fbe` |

Historical Glimmer 8k source: `ruler-results-261103/glimmer-715c81a4/results-8192.tar.gz`, SHA-256 `2ff122d17f892dcb6f495306e06d2fb1671e0b145523df18605c58a3b6bfe8f1`; its already accepted snapshot is preserved, not recalculated here.

All four Qwen manifests agree on model SHA-256 `31629f53165ab6a7dad8c9847dcfd1fdf55829dac1e6e748f4a68581b0033d34`, input lock `f42a48cc9d2ca4a0e6ab0bb986fb7b87990dee3c61cc821da53d4147ed80594b`, seed 261102, source/native commit `18d3f114e46c4f801c4a09e2c6cf8ba2303ae42d`, all 50 Python source hashes, packages, CUDA backend, flags, layout and template. Every source hash was checked against that commit. The original insertion-order input-lock serialization reconstructs f42a48cc; the archive's key-sorted exported lock has different bytes, with identical values in all six archives.

| Compared manifests | Differences besides depth | Acceptance |
|---|---|---|
| 8k vs 32k | None | Accepted by the frozen analysis |
| 8k vs 64k | 64 binary-hash leaves: client 22, node 20, partition 22; fresh build at the same commit | Accepted; the statistical loader does not compare native binary hashes across depths |
| 8k vs 128k | 21 binary-hash leaves: client 6, node 9, partition 6; node B build | Accepted; same limitation |

For example, libggml-cuda.so hashes are `379a36ea...f9d8` at 8k/32k, `2c31632c...2d77` at 64k, and `cdc23883...b311` at 128k. The complete differences and build identities are persisted in the task's manifest-diff and build-identities JSON files. These are real build differences, not a claim of byte-identical binaries across depths. The statistical tool checks paired rows, seed and family/model identity; the additional data-lock/source checks were performed in this analysis. It does not enforce whole-manifest equality across depths. The evaluator's resume gate separately requires equality of the whole manifest at a given depth.

FACTS records 64k as node A (Vast 58864154, RTX PRO 6000 Server): 369 rows before the owner-ordered stop and 21 after same-node/same-build resume. At 128k, rows 1-226 ran on node B (58969419, RTX PRO 6000 WS) and rows 227-390 on A with B's exact binaries copied to the same paths. Each example's three arms ran on one host. Host identity is not a manifest field, so an unchanged whole manifest can accompany the host change. All 225 rows saved off-node before the stop were rechecked byte-for-byte against the final rows' original pretty-JSON serialization, and the saved manifest bytes match the final manifest. This verifies the saved prefix; the 226-row handover and binary-copy execution are attributed to the stage/FACTS custody record, not newly observed here.

## Timing and bf16 disclosure

64k is labelled **collection after registration**. 128k is labelled **collection straddled registration; not confirmatory**, retaining its main-stage start at 2026-11-03T14:29:06Z against the frozen 14:36:00Z constant (the registration commit is timestamped 14:36:38Z). The separate pilot began at 14:16:37Z. The margin was fixed after Qwen 8k/32k had already been observed.

The main-stage pre-registration window is 414 s. The first archived example, niah_single_1 index 0, has serial arm-call times 127.163560637 + 98.564235609 + 133.263844227 = 358.991640473 s. The second contributes 359.549984224 s: cumulative 718.541624697 s. The evaluator runs these calls and examples sequentially and writes a row only after all three arms. Even excluding generation, release, disk and other overhead, the second row could not finish before registration. **At most one of the 390 archived rows could have been written before 14:36Z.** No row/event/log carries a row-write wall-clock timestamp; the exact count is not established (zero or one). This bound does not count the separate pilot as a main-depth example and does not justify relabelling 128k as after registration. Log hashes and the derivation are in the task report.

The registration names bf16, but 64k and 128k were never run. Its 8k/32k archives are checksum-valid and retain exactly the three frozen baseline arm results and baseline-row hash links, so no join is needed to recover those baselines. However, they name the fourth arm `offload_bf16`; the accepted tool requires `bf16`. Direct CLI invocation refuses with exit 2, `REFUSED: missing or unknown arms`, before writing an output directory. No bf16 JSON or p-value is issued in this run. A separately reviewed input adapter would need to verify the declared bf16 implementation and baseline identities, map only `results.offload_bf16` to `results.bf16`, and preserve/rebind original row-checksum provenance rather than editing source rows silently. That is new code and is outside this run. After such admission, 64k/128k must enter both bf16-local and bf16-offload four-depth families as absent p=1 upper-bound entries, explicitly never measured. No four-depth bf16 verdict is available.

## Frozen-tool tables

# Qwen: paired RULER equivalence

Differences and intervals are percentage points. Margin: +/-2 pp; alpha per side: 0.025.
Pending depths enter as p=1: reported Holm p-values are upper bounds. Accepted observed decisions cannot reverse when they arrive; raw failures cannot become equivalent.
A whole four-depth family claim remains incomplete while depths are missing.
Qwen was named in the registration.

| Depth | Pair | Difference | 95% interval | Method | TOST p | Holm p | Equivalent (raw / Holm) | Registration |
|---:|---|---:|---|---|---:|---:|---|---|
| 8192 | local_partition-local | +0.0000 | [+0.0000, +0.0000] | paired_percentile_bootstrap (DEGENERATE; not claim evidence) | 0.0001 | 0.0004 | not certified; see sidecars | observed before registration; named in registration |
| 8192 | offload-local | +0.0000 | [+0.0000, +0.0000] | paired_percentile_bootstrap (DEGENERATE; not claim evidence) | 0.0001 | 0.0004 | not certified; see sidecars | observed before registration; named in registration |
| 32768 | local_partition-local | -0.2564 | [-1.4704, +0.8517] | newcombe10 | 0.00725632 | 0.00725632 | True / True; equivalent; cannot reverse when pending depths arrive | observed before registration; named in registration |
| 32768 | offload-local | +0.0000 | [-1.0519, +1.0519] | newcombe10 | 0.00255609 | 0.00499888 | True / True; equivalent; cannot reverse when pending depths arrive | observed before registration; named in registration |
| 65536 | local_partition-local | +0.0000 | [-1.0475, +1.0475] | newcombe10 | 0.00249944 | 0.00499888 | True / True; equivalent; cannot reverse when pending depths arrive | collection after registration; named in registration |
| 65536 | offload-local | +0.0000 | [-1.0475, +1.0475] | newcombe10 | 0.00249944 | 0.00499888 | True / True; equivalent; cannot reverse when pending depths arrive | collection after registration; named in registration |
| 131072 | local_partition-local | +0.0855 | [-0.6838, +0.8547] | paired_percentile_bootstrap (unseen-range guard) | 0.0001 | 0.0004 | not certified; see sidecars | collection straddled registration; not confirmatory; named in registration |
| 131072 | offload-local | +0.0855 | [-0.6838, +0.8547] | paired_percentile_bootstrap (unseen-range guard) | 0.0001 | 0.0004 | not certified; see sidecars | collection straddled registration; not confirmatory; named in registration |

## Sidecars for degenerate sets and bootstrap passes (post-review supplement)

Claims require both sidecars. Supplementary claim Holm uses max(sidecar p) where sidecars apply; registered primary numbers above are unchanged.

| Depth | Pair | Sidecar / estimand | 95% interval (pp) | TOST p | Combined claim Holm p (upper bound) | Equivalent from both sidecars |
|---:|---|---|---|---:|---:|---|
| 8192 | local_partition-local | exact unseen discordance sidecar / mean raw score difference | [-0.9414, +0.9414] | 0.00037859033 | 0.0095531169 | True; equivalent; cannot reverse when pending depths arrive |
| 8192 | local_partition-local | binarised (score == 1) Newcombe sidecar / fully-correct rate difference | [-1.0387, +1.0387] | 0.0023882792 | 0.0095531169 | True; equivalent; cannot reverse when pending depths arrive |
| 8192 | offload-local | exact unseen discordance sidecar / mean raw score difference | [-0.9414, +0.9414] | 0.00037859033 | 0.0095531169 | True; equivalent; cannot reverse when pending depths arrive |
| 8192 | offload-local | binarised (score == 1) Newcombe sidecar / fully-correct rate difference | [-1.0387, +1.0387] | 0.0023882792 | 0.0095531169 | True; equivalent; cannot reverse when pending depths arrive |
| 131072 | local_partition-local | exact unseen range departures sidecar / mean raw score difference | [-2.2429, +2.2429] | 0.048209478 | 0.048209478 | False; equivalence not established; raw interval/sidecars fail, cannot reverse when pending depths arrive |
| 131072 | local_partition-local | binarised (score == 1) Newcombe sidecar / fully-correct rate difference | [-1.0493, +1.6307] | 0.01056404 | 0.048209478 | False; equivalence not established; raw interval/sidecars fail, cannot reverse when pending depths arrive |
| 131072 | offload-local | exact unseen range departures sidecar / mean raw score difference | [-2.2429, +2.2429] | 0.048209478 | 0.048209478 | False; equivalence not established; raw interval/sidecars fail, cannot reverse when pending depths arrive |
| 131072 | offload-local | binarised (score == 1) Newcombe sidecar / fully-correct rate difference | [-1.0493, +1.6307] | 0.01056404 | 0.048209478 | False; equivalence not established; raw interval/sidecars fail, cannot reverse when pending depths arrive |

## Collection timing against 2026-11-03 14:36Z

| Depth / pair | Start (UTC) | End (UTC) | Timing |
|---|---|---|---|
| 8192 / local_partition-local | 2026-11-03T05:52:00Z | 2026-11-03T07:32:00Z | before |
| 8192 / offload-local | 2026-11-03T05:52:00Z | 2026-11-03T07:32:00Z | before |
| 32768 / local_partition-local | 2026-11-03T07:32:00Z | 2026-11-03T14:21:00Z | before |
| 32768 / offload-local | 2026-11-03T07:32:00Z | 2026-11-03T14:21:00Z | before |
| 65536 / local_partition-local | 2026-11-03T19:20:51Z | 2026-11-05T14:28:50Z | after |
| 65536 / offload-local | 2026-11-03T19:20:51Z | 2026-11-05T14:28:50Z | after |
| 131072 / local_partition-local | 2026-11-03T14:29:06Z | 2026-11-06T05:56:57Z | straddling |
| 131072 / offload-local | 2026-11-03T14:29:06Z | 2026-11-06T05:56:57Z | straddling |

## Secondary: answer text (unchanged ruler_analysis.py)

| Depth | Offload changed / n | Partition changed / n | McNemar p | Excess 95% (pp) | Text equivalent +/-2 pp |
|---:|---:|---:|---:|---|---|
| 8192 | 34/390 | 32/390 | 0.726562 | [-2.1275, +3.1189] | False |
| 32768 | 33/390 | 29/390 | 0.617719 | [-4.0224, +6.0473] | False |
| 65536 | 28/390 | 32/390 | 0.571588 | [-5.5126, +3.4906] | False |
| 131072 | 32/390 | 27/390 | 0.38331 | [-2.6891, +5.2105] | False |

## Qwen claim decisions and descriptive cross-check

Registered Holm uses the registered TOST p. Claim Holm substitutes the maximum sidecar p wherever the frozen guard requires sidecars; it is a distinct supplementary analysis. All p-values below use their complete four-depth family within each arm pair, alpha=0.025.

<!-- BEGIN QWEN DETAIL TABLES -->
| Depth | Pair | Registered Holm p | Claim Holm p | Claim under the accepted policy |
|---:|---|---:|---:|---|
| 8192 | local_partition-local | 0.0004 | 0.00955311695 | equivalent via sidecars; degenerate primary unusable |
| 8192 | offload-local | 0.0004 | 0.00955311695 | equivalent via sidecars; degenerate primary unusable |
| 32768 | local_partition-local | 0.0072563175 | 0.014512635 | equivalent |
| 32768 | offload-local | 0.0049988767 | 0.00955311695 | equivalent |
| 65536 | local_partition-local | 0.0049988767 | 0.00955311695 | equivalent |
| 65536 | offload-local | 0.0049988767 | 0.00955311695 | equivalent |
| 131072 | local_partition-local | 0.0004 | 0.0482094776 | not established; unseen-range sidecar crosses margin |
| 131072 | offload-local | 0.0004 | 0.0482094776 | not established; unseen-range sidecar crosses margin |

Per-arm scores and secondary text statistics reproduce the accepted evaluator and the FACTS blocks at their printed precision. Text comparisons use outer-whitespace equality, exact two-sided unadjusted McNemar, Wilson 95% rate intervals, and the accepted conservative excess interval. A nonsignificant McNemar p is not equivalence.

| Depth | Local / offload / partition score (%) | Fully correct local / offload / partition | Accuracy McNemar p offload / partition |
|---:|---|---|---|
| 8192 | 97.01 / 97.01 / 97.01 | 377 / 377 / 377 | 1 / 1 |
| 32768 | 97.44 / 97.44 / 97.18 | 380 / 380 / 379 | 1 / 1 |
| 65536 | 97.18 / 97.18 / 97.18 | 379 / 379 / 379 | 1 / 1 |
| 131072 | 95.81 / 95.90 / 95.90 | 373 / 374 / 374 | 1 / 1 |

| Depth | Offload changed/n, % [Wilson 95%] | Partition changed/n, % [Wilson 95%] | Offload-only / partition-only | Text McNemar p | Excess pp [95%] | Text equivalent +/-2 pp |
|---:|---|---|---|---:|---|---|
| 8192 | 34/390, 8.72 [6.31, 11.94] | 32/390, 8.21 [5.87, 11.35] | 5 / 3 | 0.726562 | +0.5128 [-2.1275, +3.1189] | False |
| 32768 | 33/390, 8.46 [6.09, 11.65] | 29/390, 7.44 [5.23, 10.48] | 20 / 16 | 0.617719 | +1.0256 [-4.0224, +6.0473] | False |
| 65536 | 28/390, 7.18 [5.01, 10.18] | 32/390, 8.21 [5.87, 11.35] | 12 / 16 | 0.571588 | -1.0256 [-5.5126, +3.4906] | False |
| 131072 | 32/390, 8.21 [5.87, 11.35] | 27/390, 6.92 [4.80, 9.89] | 13 / 8 | 0.38331 | +1.2821 [-2.6891, +5.2105] | False |
<!-- END QWEN DETAIL TABLES -->

At 128k, three fwe paired-score differences are nonzero; the sorted first two training pairs (cwe) have zero differences. The frozen range guard counts three departures among the remaining 388 pairs, giving the [-2.2429,+2.2429] pp sidecar. The binary score==1 sidecar passes alone, but both sidecars are required. None of the bootstrap intervals triggers the near-margin sensitivity diagnostic, so no extra-seed result is generated. Finite bootstrap p resolution remains 1/10000.

All 56 Qwen ALL/per-task secondary tables match the archived analyses exactly after excluding their single-depth Bonferroni adjustment field; the frozen secondary analyser now emits its four-depth Holm field. All 52 per-task score triplets and text counts are preserved in qwen.json. The 128k cross-check is 95.81/95.90/95.90%, changed answers 32/390 and 27/390, discordant counts 13 and 8, text McNemar p=0.38331, matching the supplied archive and FACTS. Historical Glimmer descriptive numbers and its incomplete family remain unchanged. These data establish bounded RULER task-score claims at 8k/32k/64k under the accepted policy; they do not establish identical answer text, general quality equivalence outside RULER, a confirmatory 128k claim, or a complete bf16 family.

## Evidence and validation

All six archive hashes and all 48 SHA256SUMS members passed before row use. All 2340 row hashes pass; all 1560 f32 rows pass the frozen CSV/JSONL validation and paired identity checks. All 50 recorded Python source hashes per f32 depth match 18d3f114. All 56 secondary ALL/per-task rows match the accepted archived analysis (apart from the expected single-depth vs four-depth multiple-testing field). verification-01.log records the exact checks.

48 existing CPU tests pass: 35 equivalence, 11 evaluator, 2 paired-analysis/archive; every process exited 0. Direct bf16 invocation exited 2 with the intended clear refusal and no output directory. No statistical or test source changed. No surface table was supplied, so no surface-table coverage is claimed. Prior accepted mutants were not rerun for unchanged code. These results are ready for review.

The registration timing bound is conservative: only serial streaming-call durations are counted. Spec generation could precede a call, and release/other overhead is not timestamped. The main-stage log has a dated start and an ordered depth log; rows/events lack wall-clock write timestamps. The 14:16:37Z pilot is a separate stage, not evidence of additional main-depth completed examples. Thus zero or one pre-registration archived row is unresolved, not an assertion that one definitely existed.

| Timing/reference input | SHA-256 |
|---|---|
| .temp/hybrid-d-r16e-261106/FACTS.snapshot.md | 78253a8a6b59a661cd40761c01557d460ce197da56b0a57e93bcc9bff0c96866 |
| .temp/hybrid-d-r16e-261106/timing-inputs/depth-131072.log | d1cf95081da8ff74277f01799b8e67fb5e322732c41763f2890e4dae5f851003 |
| .temp/hybrid-d-r16e-261106/timing-inputs/stage-r128-attempt1.log | 6f97f7b7ccee172cc2c86ca9f2de748fdcddc8449a63f76e677a04151ad089d7 |
| .temp/hybrid-d-r16e-261106/timing-inputs/stage-r128.log | 2a85b10cba4393baacda74fe46586520016b2b5717e5b89db49409d773f83780 |

Timing logs were copied read-only from /home/agent/lanes/hybrid/.temp/ruler-results-261105/x/58969419/logs/logs/. The accepted evaluator serial loop is ruler_eval.py at 18d3f114, lines 139-176 and 278-310. Prefix originals are under the same saved node's logs/src-ruler/.temp/ruler-r128/results/depth-131072/{rows,manifest.json}; exact file hashes are persisted in old-prefix-hashes.json. Build hash leaves and every manifest difference are in build-identities.json and manifest-diff-8192-*.json. input-ledger.json lists full hashes of every archive member. The source FACTS snapshot hash above fixes the cross-check reference; stale interim/pending descriptions in FACTS are superseded by this completion result, not silently reused as primary verdicts.

Regeneration: execute the self-contained shell block in the committed RULER-EQUIVALENCE-RESULTS.md. It verifies the six original archives, recreates only small local inputs, passes the supplied --run-times, runs the 48 frozen tests, regenerates qwen.json and all Qwen tables, preserves Glimmer, then deletes the extracts. Supplementary audit scripts under this .temp are CPU provenance/formatting checks only, not new statistical implementations.

## Signed delivery

Head 01b498364cea4cb918e21e244096af08ecc51f82 on m3-ruler-equivalence; signature verified, %G?=G, requested co-author trailer present. Only RULER-EQUIVALENCE-RESULTS.md and equivalence-results/qwen.json changed. m3-near-ties remains 250f2239060655c6b298a00471c63d957fb61900. No push. Source and tests unchanged from e46e5623.

On this signed head: tests-equivalence-head-01.log has 35 tests, tests-eval-head-01.log 11, tests-secondary-head-01.log 2; all three processes exit0, total48. verify-commit-01.log exits0. Documented extraction/CLI/formatting commands reran with exit0 and reproduced the report and JSON byte-identically; regeneration-comparison-01.log also verifies unchanged Glimmer. All task-owned row extracts removed; input archives and small evidence copies retained. Disk df -BG30G available. The expected bf16 refusal exits2. a2a --help readiness exits0; post --help is unsupported (flag help requested, exit2), with the supported post syntax read from the main help.

Requested coordinator summary sent to agents1_hybrid_orch in #hybrid, topic prototype-go; a2a-summary-01.log, process exit0.
