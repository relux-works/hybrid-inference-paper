- **Paired RULER for Qwen at 128k, COMPLETE (node B rows 1-226, node A the rest with B's exact build; 2026-11-03
  14:29:06Z to 2026-11-06 05:56:57Z).** The evaluator's own analysis; the registered four-depth analysis with Holm is
  dev-d r16e (pending). The completion details follow in the block below.
  - **Run.** 390/390 examples: 13 tasks × 30, seed 261102, input lock f42a48cc. On completion the stage verified
    that the saved manifest and all 226 rows written before the resume were byte-unchanged, and the archive checksum.
    - Archive `complete.tar.gz` sha256 36da2f0328ad2145dcab3ed47cc215744708d66b90602b42e0495666baecc94e; manifest sha256
      b8fdacf3...ceea.
    - Download bundle `r128-complete.tgz` sha256 c9d0b52b4518f44157a4345b77eea116444e5fd2397412bf9b58ba27cf984bb2,
      60,364,803 B, equal on node A and agents1. Path: `.temp/ruler-results-261106/r128-complete/`.
    - The 225 rows saved off-node before the 11-04 stop are byte-identical in the final set. The manifest is identical
      to the one saved off-node.
  - **Scores.** By task, every arm gives:
    - qa_2: 50.00%;
    - qa_1: 96.67%;
    - every other task: 100%, except fwe.

    | Arm | All tasks | fwe |
    |---|---|---|
    | local | 95.81% | 98.89% |
    | offload | 95.90% | 100% |
    | partition | 95.90% | 100% |

    Offload against local, accuracy McNemar: p = 1.
  - **Changed answers against local** (outer-whitespace equality):
    - offload 32/390 = 8.21%, Wilson [5.87, 11.35];
    - partition 27/390 = 6.92%, Wilson [4.80, 9.89];
    - offload only 13, partition only 8; McNemar p = 0.3833, two-sided exact, unadjusted.
    - By task, offload / partition changes: cwe 13/10, fwe 4/3, niah_multikey_2 4/4, niah_multivalue 3/3,
      niah_single_3 3/3, niah_multikey_3 2/2, qa_2 2/2, qa_1 1/0, every other task 0/0.
  - **Excess of offload over partition:** +1.28 pp, conservative 95% interval [−2.69, +5.21] pp.
    - Strict «no more changes than partition» is not established, and neither is equivalence at ±2 pp.
  - **Timing against the registration** (2026-11-03 14:36Z, commit `7556f461` at 14:36:38Z): the 128k depth started at
    14:29:06Z, 7 minutes before it; the pilot ran at 14:16:37Z. By the tool's frozen rule this is «straddling». 64k
    started at 19:20:51Z, after it. dev-d r16e reports how many 128k rows could have been written before 14:36Z.
  - **The frozen RULER data is saved off-node.** `ruler-data-f42a48cc.tgz`, sha256
    35dfad90982dc6b33cdad747500d00616cf9f92a7b1393d706f31206f8ce70fa, 103,351,949 B, 482 entries.
    - It holds `data/` (its `inputs.lock.json` hashes to f42a48cc), the `data-bootstrap-mismatch-141425` directory
      (a fresh bootstrap's drift on the essay pages), `build.lock` and `input-lock.sha256`.
    - Path: `.temp/ruler-results-261106/ruler-data/`. Private (essay texts), not for the public repository.
  - **Nodes destroyed** 2026-11-06 06:03:58Z, after the results and data were verified on agents1: node A (Vast 58864154)
    and node B (58969419). Both API deletes returned success, and the v1 instance list shows only node V (59296672).
    This follows the analyst's rule, relayed by the owner: delete once the computed examples are saved off the nodes.
  - **Statement:** at 128k, offload and the partition control score the same as local (95.90% against 95.81%), and both
    change answer text at similar rates (8.2% and 6.9%). n = 390 cannot establish equivalence of the changed-text rate
    within ±2 pp.

