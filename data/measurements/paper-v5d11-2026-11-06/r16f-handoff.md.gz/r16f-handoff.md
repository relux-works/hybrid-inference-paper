# RULER bf16, hybrid-d-r16f-261106

CPU analysis from signed r16e 01b498364cea4cb918e21e244096af08ecc51f82, branch m3-ruler-equivalence. The new input adapter does not change statistical code. Qwen f32/Glimmer JSON and their generated table blocks remain byte-identical. Both requested bf16 families are analysed over the two depths that exist, with absent 64k/128k entered as p=1.

## FACTS-ready block (English)

**Registered bf16 RULER, 8k and 32k (dev-d r16f, 2026-11-06).** The reviewed state-bf16 candidate is 8d876c71b798651a8c5df768dc374468ced77544. A separate checked input adapter verifies the two bf16 archives and corresponding f32 baselines, maps only offload_bf16 to bf16, and preserves all original/derived/baseline row-hash links. The statistical analyser is unchanged from accepted e46e5623. Both depths have 390 matched examples, seed 261102, model 31629f53..., data lock f42a48cc.... All 780 bf16 scores equal the corresponding local and f32-offload scores.

| Depth | Pair | Difference pp | 95% interval pp | Method | TOST p | Registered Holm p upper bound | Supplementary claim Holm p upper bound | Claim |
|---:|---|---:|---|---|---:|---:|---:|---|
| 8192 | bf16-local | +0.0000 | [+0.0000, +0.0000] | paired_percentile_bootstrap | 0.0001 | 0.0004 | 0.00955311695 | equivalent via both sidecars; primary degenerate |
| 8192 | bf16-offload | +0.0000 | [+0.0000, +0.0000] | paired_percentile_bootstrap | 0.0001 | 0.0004 | 0.00955311695 | equivalent via both sidecars; primary degenerate |
| 32768 | bf16-local | +0.0000 | [-1.0519, +1.0519] | newcombe10 | 0.00255608516 | 0.00766825548 | 0.00955311695 | equivalent |
| 32768 | bf16-offload | +0.0000 | [-1.0519, +1.0519] | newcombe10 | 0.00255608516 | 0.00766825548 | 0.00955311695 | equivalent |

- At 8k, the registered bootstrap is degenerate [0,0] pp and cannot certify. Both bf16-local and bf16-offload instead use the exact unseen-discordance sidecar [-0.9414,+0.9414] pp (TOST p=0.000378590333) and score==1 Newcombe sidecar [-1.0387,+1.0387] pp (p=0.00238827924); both pass. At 32k, all scores are binary and Newcombe method 10 applies. Supplementary claim Holm p=0.00955311695 for every observed pair/depth; registered Holm is reported separately above. The equivalence margin is +/-2 pp, alpha=0.025 per side.
- bf16 at 64k and 128k was never measured. Both missing entries are p=1 in each four-depth family, so the adjusted p-values are upper bounds. These accepted observed-depth decisions cannot reverse when absent entries are replaced by future data under the same frozen rules. Neither whole four-depth bf16 family is complete; no claim for the missing depths is supported.
- Timing: the stage's execute window is 2026-11-03T14:23:39Z to 18:41:33Z; rc=1 is a post-arm service restore failure, not an incomplete arm. The stage builds/restarts/preflights before example generation. The sum of 390 serial 8k bf16 call durations is 3027.088313445449 s, exceeding the 741 s before registration at 14:36:00Z, which proves completion after registration but does not locate its first call. **8k timing is unknown (after or straddling), not confirmatory.** The sequential 32k arm follows the complete 8k arm; it cannot start before 15:14:06Z as a conservative lower bound and therefore is **after registration**. Its 390 serial calls total 11315.0215302594 s. The 32k timing map [15:14:06Z,18:41:33Z] is an enclosing bound, not measured per-depth timestamps. No per-depth timestamp is invented.
- These are RULER score-equivalence results at two measured depths and a specific model/transport implementation. They do not establish identical answer text, quality equivalence outside RULER, or higher-depth bf16 equivalence. Qwen f32/Glimmer results are unchanged.

## Input hashes

All four compressed hashes and all 32 internal SHA256SUMS members were verified before row admission. All 1560 original row hashes and 780 derived row hashes pass. The source archives are read-only and unchanged.

| Original archive | SHA-256 |
|---|---|
| /home/agent/lanes/hybrid/.temp/ruler-results-261103/bf16-8d876c71/bf16-8192-complete.tar.gz | c0348572c2c1baf50dcfcdd0a73397594ba0d12e45ba157b0ae63980f25799b6 |
| /home/agent/lanes/hybrid/.temp/ruler-results-261103/depth-8192-complete.tar.gz | 2be3eae64b783867258a1f22e1c7bbdb4188f257c378f17c07554a8868248aa4 |
| /home/agent/lanes/hybrid/.temp/ruler-results-261103/bf16-8d876c71/bf16-32768-complete.tar.gz | 5efae77aa8b9902bd31b9b2a1ba336a0d8a090353898fd31fee8c980e73e1fbe |
| /home/agent/lanes/hybrid/.temp/ruler-results-261103/depth-32768-complete.tar.gz | a6fb1e7e6ac0fb7d25ed3ed24ef1f47cdf4f6495b54a4866d6486870bfeef176 |

## bf16 admission and the two measured depths (r16f)

The separate [input adapter](/home/agent/Werkstatt/hybrid-d/llama.cpp/tools/hybrid-eval/ruler_bf16_adapter.py) admits the existing reviewed state-bf16 experiment at 8d876c71. It performs no statistics. All four compressed input hashes and all 32 SHA256SUMS members pass before manifest/row use. Every original row_sha256 is mandatory; all 1560 source rows and 780 derived rows validate. Source archives are never modified. Candidate adapter source is self-reviewed and CPU-tested, ready for review; this does not claim a new independent acceptance verdict.

Admission pins model 31629f53..., data lock f42a48cc..., seed 261102, baseline source 18d3f114 and declared bf16 implementation 8d876c71b798651a8c5df768dc374468ced77544. The canonical implementation digest a0a79998860655482a11add7d8fea80dd61fbd2f5478fabaa5e56a5e5349250e covers all 55 recorded source hashes and the commits/binary hashes of three services. Its values agree between the two owner-hashed archives; all 55 source hashes also match the signed 8d876c71 object in the local mirror. This verifies declared build identity, not a new execution of destroyed hardware. The adapter checks the exact baseline manifest and implementation links, every baseline_row_sha256, the same complete task/index set, unchanged three baseline arm results and input metadata, and bf16 trace identity. Unknown or additional fourth arms refuse. Only results.offload_bf16 becomes results.bf16; all other source fields stay intact. Each derived row records original_row_sha256 beside its new row_sha256. A receipt retains all 780 original/derived/baseline row-hash links, archive/member hashes and the adapter source hash.

Committed outputs: [bf16 frozen-tool snapshot](/home/agent/Werkstatt/hybrid-d/llama.cpp/tools/hybrid-eval/equivalence-results/qwen-bf16.json) and [input/timing provenance](/home/agent/Werkstatt/hybrid-d/llama.cpp/tools/hybrid-eval/equivalence-results/bf16-input-provenance.json). The raw snapshot also contains the frozen baseline comparisons and f32 secondary tables that the unchanged CLI always emits; these do not replace qwen.json or update the accepted four-depth f32 results. Only bf16-local and bf16-offload are reported below. The statistical tool, its 48 existing tests, qwen.json, glimmer.json and their generated table blocks remain byte-identical to r16e.

### bf16 timing: bounds, not invented timestamps

The only stage window is 2026-11-03T14:23:39Z to 18:41:33Z, with 8k first. Stage return code 1 came from the post-arm service restore; both arms were complete. The registration constant is unchanged at 14:36:00Z. No per-depth wall-clock timestamp survives. The pinned stage executes build, service restart and preflight after execute begins, before either depth; treating execute start as a measured 8k start would be unjustified (stage_ruler_bf16.py at 8d876c71, lines 165-206). The single-arm evaluator runs calls serially (ruler_eval.py at that commit, lines 297-315).

| Depth | Sum of its 390 serial bf16 call durations | What follows | Classification |
|---:|---:|---|---|
| 8192 | 3027.088313445449 s | Exceeds the 741 s execute-to-registration gap, so completion is after registration; first-call time unknown | unknown; may be after or straddling |
| 32768 | 11315.0215302594 s | Follows the complete 8k arm, hence begins no earlier than execute start +3027.088313445449 s | after registration |

A conservative enclosing window for 32k is [2026-11-03T15:14:06Z, 2026-11-03T18:41:33Z]: start is the lower bound rounded down, end is the whole stage's upper bound. These are not measured per-depth endpoints. That enclosing window is passed through --run-times only for bf16 32768; bf16 8192 has no map entry, so the frozen tool correctly emits unknown and not confirmatory. The saved timing provenance marks these semantics explicitly. No claim is made that 8k was observed before registration.

### bf16 score claims and missing-depth policy

Both comparisons have 390 matched examples at each measured depth. Every bf16 score equals both its local and f32-offload score. At 8k the registered percentile bootstrap is degenerate [0,0] pp; its p=0.0001 floor and registered Holm p=0.0004 cannot certify a claim. Both post-review sidecars instead support equivalence, each with approximately 1 pp half-width. At 32k, all scores are binary and Newcombe method 10 applies. No near-margin diagnostic triggers. All four observed pair/depth claims pass the accepted policy, with supplementary claim Holm p=0.00955311695 for each. The 32k registered TOST p=0.00255608516 and registered Holm p=0.00766825548 are distinct from that supplementary claim p.

64k and 128k bf16 were never measured. Both enter each of the two four-depth families as absent p=1, not observed failures or planned completed measurements. Every displayed Holm p is an upper bound while those entries are absent. Replacing these p=1 values by future data cannot reverse these accepted observed-depth decisions under the frozen rules. Neither whole four-depth bf16 family is complete, and no equivalence or general quality claim is made for those missing depths. The 8k timing classification prevents a confirmatory temporal claim for that depth.

<!-- BEGIN BF16 TABLES -->
### Qwen bf16: paired RULER score equivalence

Differences and intervals are percentage points. Margin: +/-2 pp; alpha per side: 0.025.
Pending depths enter as p=1: reported Holm p-values are upper bounds. Accepted observed decisions cannot reverse when they arrive; raw failures cannot become equivalent.
A whole four-depth family claim remains incomplete while depths are missing.
Qwen was named in the registration.

| Depth | Pair | Difference | 95% interval | Method | TOST p | Holm p | Equivalent (raw / Holm) | Registration |
|---:|---|---:|---|---|---:|---:|---|---|
| 8192 | bf16-local | +0.0000 | [+0.0000, +0.0000] | paired_percentile_bootstrap (DEGENERATE; not claim evidence) | 0.0001 | 0.0004 | not certified; see sidecars | unknown collection timing; named in registration; not confirmatory |
| 8192 | bf16-offload | +0.0000 | [+0.0000, +0.0000] | paired_percentile_bootstrap (DEGENERATE; not claim evidence) | 0.0001 | 0.0004 | not certified; see sidecars | unknown collection timing; named in registration; not confirmatory |
| 32768 | bf16-local | +0.0000 | [-1.0519, +1.0519] | newcombe10 | 0.00255609 | 0.00766826 | True / True; equivalent; cannot reverse when pending depths arrive | collection after registration; named in registration |
| 32768 | bf16-offload | +0.0000 | [-1.0519, +1.0519] | newcombe10 | 0.00255609 | 0.00766826 | True / True; equivalent; cannot reverse when pending depths arrive | collection after registration; named in registration |

## Sidecars for degenerate sets (post-review supplement)

Claims require both sidecars. Supplementary claim Holm uses max(sidecar p) at a degenerate depth and the registered p otherwise; registered primary numbers above are unchanged.

| Depth | Pair | Sidecar / estimand | 95% interval (pp) | TOST p | Combined claim Holm p (upper bound) | Equivalent from both sidecars |
|---:|---|---|---|---:|---:|---|
| 8192 | bf16-local | exact unseen discordance sidecar / mean raw score difference | [-0.9414, +0.9414] | 0.00037859033 | 0.0095531169 | True; equivalent; cannot reverse when pending depths arrive |
| 8192 | bf16-local | binarised (score == 1) Newcombe sidecar / fully-correct rate difference | [-1.0387, +1.0387] | 0.0023882792 | 0.0095531169 | True; equivalent; cannot reverse when pending depths arrive |
| 8192 | bf16-offload | exact unseen discordance sidecar / mean raw score difference | [-0.9414, +0.9414] | 0.00037859033 | 0.0095531169 | True; equivalent; cannot reverse when pending depths arrive |
| 8192 | bf16-offload | binarised (score == 1) Newcombe sidecar / fully-correct rate difference | [-1.0387, +1.0387] | 0.0023882792 | 0.0095531169 | True; equivalent; cannot reverse when pending depths arrive |

## Collection timing against 2026-11-03 14:36Z

| Depth / pair | Start (UTC) | End (UTC) | Timing |
|---|---|---|---|
| 8192 / bf16-local | None | None | unknown |
| 8192 / bf16-offload | None | None | unknown |
| 32768 / bf16-local | 2026-11-03T15:14:06Z | 2026-11-03T18:41:33Z | after |
| 32768 / bf16-offload | 2026-11-03T15:14:06Z | 2026-11-03T18:41:33Z | after |

<!-- END BF16 TABLES -->

### Adapter validation and review coverage

The full CPU suite has 72 tests: the unchanged 48 plus 24 new adapter tests. Real 8k and 32k inputs are positive controls, not synthetic substitutes; tests require four staged archives via RULER_BF16_TEST_INPUTS and do not download. Every named negative checks the intended exit 2, a clear refusal, no traceback and no created output. The existing-output negative instead verifies preservation of its sentinel. All original input bytes are preserved.

| Check | Count / real exit | Evidence under .temp/hybrid-d-r16f-261106/ |
|---|---|---|
| Full old + new CPU suite | 72 / 0 | tests-full-01.log; repeated on signed head in tests-full-head-01.log |
| Real adapter runs | 2 processes / 0 | adapt-8192-03.log, adapt-32768-03.log |
| Frozen bf16-family analysis | 0 | analysis-02.log |
| Exact identity, provenance, unchanged f32/Glimmer, regeneration checks | 0 | validation-01.log |

| Mutant | What it narrows the gate to | Named test that fails | Real exit / bound |
|---|---|---|---|
| Map f32 offload instead of bf16 | Correct score equality alone must not substitute the wrong transported arm | test_real_8k_archive_admitted_with_exact_mapping_and_provenance | 1; intended assertion failure |
| Skip baseline-arm equality | A valid resealed row must not replace any frozen baseline result | test_baseline_mismatch_refuses | 1; intended assertion failure |

Both requested mutants are killed; no survivors. These finite controls establish the named mapping/baseline properties, not exhaustive malformed-input coverage. Source changes are confined to tools/hybrid-eval. Scope/security/design/tests/general self-review found no remaining blocker. No surface table was supplied; no surface-table coverage is claimed. No out-of-contract requested row remains: bf16 at 64k/128k is explicitly absent under task clause 3, and 8k timing is unknown under clause 4. Native/CUDA tests and builds are inapplicable to this stdlib-only input adapter and were not run. No network, GPU or supervisor changes occurred; no push or landing is claimed. Temporary adapted row copies are deleted after evidence/regeneration checks; row-hash receipts remain committed.


## Evidence, self-review and regeneration

The input-adapter implementation digest is fixed in source, not accepted from the input being admitted. All 55 source hashes per bf16 manifest were checked against the signed 8d876c71 object in the local mirror. Native binary hashes are verified as declared identities; the destroyed node was not re-executed. Exact f32 baseline manifest identity, native/source implementation identity, 390 baseline row links and all three baseline arm results are checked before output. Provenance copies all original/derived row hashes into the committed bf16-input-provenance.json, so temporary adapted rows can be removed without losing the audit mapping.

72 CPU tests pass before signing (48 unchanged +24 new; tests-full-01.log, exit0). Both requested mutants fail their named assertions, each exit1; no survivors (mutants-02.log). Initial fixture tests had three failures because a helper rewrote baseline-manifest whitespace and hit the earlier identity refusal; the fixture was corrected to preserve the unchanged manifest bytes, without weakening admission. tests-adapter-03.log and the full suite are green. The final source/test identity is the one exercised by the current-source mutants. AST/ASCII checks, every report heredoc, preserved f32/Glimmer blocks, all 780 hash links and byte-identical replay outputs pass in validation-01.log, exit0.

The report/README include self-contained regeneration commands. Replay used those exact adapter/timing/statistical/formatting commands in a separate task-owned directory (regeneration-01.log, exit0). Original and replay derived rows, manifests, receipts and raw frozen-tool JSON are byte-identical. Old statistical and test sources are unchanged from 01b49836/e46e5623. No network, GPU, native build, package install or supervisor access. No surface table was supplied; no surface-table coverage is claimed. All requested rows are in contract; absent 64k/128k and unknown 8k timing are declared under task clauses3/4. Candidate adapter/results are ready for review, with no new independent acceptance claim.

## Signed delivery

Head 779e66a322d53e1b7ccba535e3497b544e358983 on m3-ruler-equivalence. Signed commit verified (exit0, %G?=G), exact requested co-author trailer present. Only six paths under tools/hybrid-eval changed: the adapter, its24tests, README/report and two new bf16 JSON artifacts. Existing statistical code, all48legacytestsourcebytes, f32/Glimmer JSON and generated tables remain unchanged. Worktree clean; no push. m3-near-ties stays250f2239060655c6b298a00471c63d957fb61900.

The full suite ran directly on this signed head:72tests (48existing+24new), exit0, tests-full-head-01.log. Both current-source mutant plants match the exact signed adapter bytes after only their declared replacements; their named tests fail with intended assertion failures at exit1. Own original/replay adapted row trees were removed after exact-byte checks (9,426,586B);780hash-link receipts remain committed. Source archives and small local test-fixture copies are retained; df -BG30G available. Candidate is ready for review.

Requested summary sent to agents1_hybrid_orch in #hybrid, topic prototype-go; a2a-summary-01.log, exit0.
