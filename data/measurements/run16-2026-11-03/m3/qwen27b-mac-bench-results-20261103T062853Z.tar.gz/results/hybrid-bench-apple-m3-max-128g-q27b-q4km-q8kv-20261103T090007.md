| depth | segment prefill tok/s | Δ512 prefill tok/s | Δ2000 prefill tok/s | Δ10000 prefill tok/s | decode tok/s (at depth) |
|---|---|---|---|---|---|
| 16k (cum. 1.4 min) | 191.5 | 174.2 | 176.9 | 156.3 | 14.99 |
| 50k (cum. 4.1 min) | 128.8 | 121.7 | 116.1 | 106.7 | 13.52 |
| 100k (cum. 11.7 min) | 81.4 | 65.3 | 66.2 | 63.5 | 10.36 |
| 150k (cum. 23.5 min) | 52.5 | 46.2 | 47.1 | 44.4 | 8.99 |
| 200k (cum. 39.7 min) | 38.2 | 36.5 | 36.8 | 34.5 | 7.82 |
| 249k (cum. 59.7 min) | 30.1 | 28.7 | 29.7 | 27.8 | 6.93 |
slot save at 16k: 714 MB = 43.6 KiB/token, 771.045 ms
slot save at 50k: 1899 MB = 37.1 KiB/token, 1867.093 ms
slot save at 100k: 3641 MB = 35.6 KiB/token, 3567.972 ms
slot save at 150k: 5383 MB = 35.0 KiB/token, 5298.653 ms
slot save at 200k: 7126 MB = 34.8 KiB/token, 7030.467 ms
slot save at 249k: 8833 MB = 34.6 KiB/token, 8747.108 ms
