| depth | segment prefill tok/s | Δ512 prefill tok/s | Δ2000 prefill tok/s | Δ10000 prefill tok/s | decode tok/s (at depth) |
|---|---|---|---|---|---|
| 16k (cum. 0.1 min) | 4294.6 | 3876.4 | 3908.8 | 3777.7 | 63.78 |
| 50k (cum. 0.2 min) | 3240.8 | 2652.8 | 2715.6 | 2656.8 | 57.25 |
| 100k (cum. 0.4 min) | 2254.9 | 1806.9 | 1767.1 | 1888.3 | 49.61 |
| 150k (cum. 0.8 min) | 1699.0 | 1381.5 | 1344.9 | 1476.5 | 43.47 |
| 200k (cum. 1.3 min) | 1365.4 | 1111.2 | 1097.3 | 1214.4 | 38.39 |
| 249k (cum. 1.8 min) | 1144.0 | 950.3 | 924.6 | 1035.3 | 34.51 |
slot save at 16k: 714 MB = 43.6 KiB/token, 232.056 ms
slot save at 50k: 1899 MB = 37.1 KiB/token, 578.907 ms
slot save at 100k: 3641 MB = 35.6 KiB/token, 1115.775 ms
slot save at 150k: 5383 MB = 35.0 KiB/token, 1609.912 ms
slot save at 200k: 7126 MB = 34.8 KiB/token, 2226.75 ms
slot save at 249k: 8833 MB = 34.6 KiB/token, 3450.827 ms
