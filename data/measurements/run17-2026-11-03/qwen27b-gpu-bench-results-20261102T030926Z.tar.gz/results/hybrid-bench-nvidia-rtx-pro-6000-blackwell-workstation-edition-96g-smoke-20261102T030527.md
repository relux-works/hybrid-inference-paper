| depth | segment prefill tok/s | Δ256 prefill tok/s | Δ512 prefill tok/s | decode tok/s (at depth) |
|---|---|---|---|---|
| 2k (cum. 0.0 min) | 4196.4 | 3805.2 | 3982.9 | 71.06 |
| 4k (cum. 0.0 min) | 4333.4 | 3748.4 | 3903.3 | 71.03 |
