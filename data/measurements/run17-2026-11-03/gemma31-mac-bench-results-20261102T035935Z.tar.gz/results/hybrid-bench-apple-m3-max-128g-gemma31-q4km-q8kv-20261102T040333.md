| depth | segment prefill tok/s | Δ512 prefill tok/s | Δ2000 prefill tok/s | Δ10000 prefill tok/s | decode tok/s (at depth) |
|---|---|---|---|---|---|
| 16k (cum. 2.0 min) | 134.8 | 114.9 | 116.0 | 105.5 | 9.04 |
| 50k (cum. 6.9 min) | 71.1 | 58.9 | 50.2 | 42.1 | 6.58 |
| 100k (cum. 27.0 min) | 30.9 | 24.8 | 26.2 | 25.7 | 5.01 |
| 150k (cum. 57.6 min) | 20.2 | 20.0 | 20.3 | 16.8 | 4.2 |
| 200k (cum. 97.3 min) | 15.6 | 16.2 | 16.5 | 13.8 | 3.64 |
| 249k (cum. 148.9 min) | 11.7 | 14.2 | 13.3 | 10.9 | 3.15 |
slot save at 16k: 1142 MB = 69.7 KiB/token, 1108.835 ms
slot save at 50k: 2622 MB = 51.2 KiB/token, 3877.317 ms
slot save at 100k: 4799 MB = 46.9 KiB/token, 10107.268 ms
slot save at 150k: 6976 MB = 45.4 KiB/token, 15554.805 ms
slot save at 200k: 9153 MB = 44.7 KiB/token, 28004.484 ms
slot save at 249k: 11286 MB = 44.3 KiB/token, 46811.763 ms
