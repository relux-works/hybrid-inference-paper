| depth | segment prefill tok/s | Δ256 prefill tok/s | Δ512 prefill tok/s | decode tok/s (at depth) |
|---|---|---|---|---|
| 4k (cum. 0.4 min) | 155.7 | 144.0 | 146.4 | 7.12 |
