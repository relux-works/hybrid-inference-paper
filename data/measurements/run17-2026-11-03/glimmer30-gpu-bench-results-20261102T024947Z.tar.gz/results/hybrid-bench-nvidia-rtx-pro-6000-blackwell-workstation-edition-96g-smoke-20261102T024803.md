| depth | segment prefill tok/s | Δ256 prefill tok/s | Δ512 prefill tok/s | decode tok/s (at depth) |
|---|---|---|---|---|
| 4k (cum. 0.0 min) | 4475.5 | 3704.9 | 3896.9 | 79.34 |
