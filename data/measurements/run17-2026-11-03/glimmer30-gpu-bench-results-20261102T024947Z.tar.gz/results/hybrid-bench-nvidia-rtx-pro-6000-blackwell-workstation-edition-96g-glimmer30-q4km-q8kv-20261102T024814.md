| depth | segment prefill tok/s | Δ512 prefill tok/s | Δ2000 prefill tok/s | Δ10000 prefill tok/s | decode tok/s (at depth) |
|---|---|---|---|---|---|
| 16k (cum. 0.1 min) | 4467.5 | 4041.7 | 4171.0 | 4220.9 | 73.42 |
| 50k (cum. 0.1 min) | 3986.1 | 3377.9 | 3615.8 | 3711.7 | 68.11 |
| 100k (cum. 0.3 min) | 3427.7 | 2724.6 | 3014.8 | 3126.4 | 61.61 |
| 118k (cum. 0.4 min) | 3028.4 | 2530.9 | 2822.8 | 2935.5 | 59.37 |
slot save at 16k: 157 MB = 9.6 KiB/token, 53.196 ms
slot save at 50k: 398 MB = 7.8 KiB/token, 130.549 ms
slot save at 100k: 752 MB = 7.3 KiB/token, 253.221 ms
slot save at 118k: 880 MB = 7.3 KiB/token, 299.706 ms
