| depth | segment prefill tok/s | Δ256 prefill tok/s | Δ512 prefill tok/s | decode tok/s (at depth) |
|---|---|---|---|---|
| 4k (cum. 0.0 min) | 3649.4 | 3089.5 | 3220.4 | 65.28 |
