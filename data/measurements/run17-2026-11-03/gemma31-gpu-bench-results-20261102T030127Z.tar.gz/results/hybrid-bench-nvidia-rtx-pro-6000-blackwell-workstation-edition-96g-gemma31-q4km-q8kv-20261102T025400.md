| depth | segment prefill tok/s | Δ512 prefill tok/s | Δ2000 prefill tok/s | Δ10000 prefill tok/s | decode tok/s (at depth) |
|---|---|---|---|---|---|
| 16k (cum. 0.1 min) | 3475.6 | 3024.9 | 2976.6 | 2683.9 | 56.0 |
| 50k (cum. 0.3 min) | 1959.4 | 1613.6 | 1632.8 | 1560.0 | 44.06 |
| 100k (cum. 0.8 min) | 1247.8 | 1019.1 | 1039.1 | 1017.6 | 33.48 |
| 150k (cum. 1.5 min) | 879.0 | 745.5 | 767.2 | 761.0 | 27.02 |
| 200k (cum. 2.4 min) | 681.4 | 592.7 | 613.3 | 610.3 | 22.62 |
| 249k (cum. 3.4 min) | 559.3 | 492.1 | 510.5 | 510.7 | 19.51 |
slot save at 16k: 1142 MB = 69.7 KiB/token, 346.02 ms
slot save at 50k: 2622 MB = 51.2 KiB/token, 785.267 ms
slot save at 100k: 4799 MB = 46.9 KiB/token, 1481.507 ms
slot save at 150k: 6976 MB = 45.4 KiB/token, 2212.943 ms
slot save at 200k: 9153 MB = 44.7 KiB/token, 8835.279 ms
slot save at 249k: 11286 MB = 44.3 KiB/token, 3749.904 ms
