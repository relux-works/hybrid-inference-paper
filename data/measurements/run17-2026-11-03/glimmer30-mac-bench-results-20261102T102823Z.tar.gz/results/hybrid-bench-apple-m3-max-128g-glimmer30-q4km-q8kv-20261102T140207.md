| depth | segment prefill tok/s | Δ512 prefill tok/s | Δ2000 prefill tok/s | Δ10000 prefill tok/s | decode tok/s (at depth) |
|---|---|---|---|---|---|
| 16k (cum. 1.4 min) | 186.6 | 173.2 | 174.7 | 174.6 | 10.48 |
| 50k (cum. 4.0 min) | 135.4 | 104.5 | 105.8 | 101.1 | 9.29 |
| 100k (cum. 11.3 min) | 85.3 | 87.6 | 69.6 | 80.0 | 7.61 |
| 118k (cum. 12.9 min) | 52.6 | 50.4 | 54.0 | 58.0 | 7.21 |
slot save at 16k: 157 MB = 9.6 KiB/token, 256.882 ms
slot save at 50k: 398 MB = 7.8 KiB/token, 610.656 ms
slot save at 100k: 752 MB = 7.3 KiB/token, 1195.601 ms
slot save at 118k: 880 MB = 7.3 KiB/token, 2326.549 ms
