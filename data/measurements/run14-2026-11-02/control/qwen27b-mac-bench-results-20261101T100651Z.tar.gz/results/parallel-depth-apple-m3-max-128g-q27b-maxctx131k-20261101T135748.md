# Parallel decode at depth 131072: apple-m3-max-128g-q27b-maxctx131k

parallel_depth 1.1; model 31629f53165ab6a7dad8c9847dcfd1fdf55829dac1e6e748f4a68581b0033d34; build b11087-c21284cdf; 128 tokens per stream.

| Streams | Aggregate decode, tok/s | Mean per stream, tok/s | Gain over one stream | Restore reused |
|---:|---:|---:|---:|---|
| 1 | 7.683 | 7.68 | 1.0 | True |
| 2 | 11.488 | 5.75 | 1.495 | True |
| 4 | 12.966 | 3.24 | 1.688 | True |
| 6 | 13.348 | 2.23 | 1.737 | True |
| 8 | 12.67 | 1.58 | 1.649 | True |

Aggregate: timed decode steps of all streams divided by the longest server decode interval. A round with restore_reused false re-read more than the suffix; treat its numbers with care.
