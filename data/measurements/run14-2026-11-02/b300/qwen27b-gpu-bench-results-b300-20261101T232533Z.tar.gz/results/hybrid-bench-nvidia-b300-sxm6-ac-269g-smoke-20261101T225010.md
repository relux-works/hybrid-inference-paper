| depth | segment prefill tok/s | Δ256 prefill tok/s | Δ512 prefill tok/s | decode tok/s (at depth) |
|---|---|---|---|---|
| 2k (cum. 0.0 min) | 746.1 | 1640.3 | 1700.5 | 79.67 |
| 4k (cum. 0.1 min) | 1727.5 | 1632.4 | 1690.4 | 91.46 |
