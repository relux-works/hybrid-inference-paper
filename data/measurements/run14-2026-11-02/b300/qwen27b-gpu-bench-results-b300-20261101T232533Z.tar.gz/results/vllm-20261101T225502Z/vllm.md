# vLLM cold prefill (method A)

T(L)=aL+bL²/2, seconds; derivative rate=1/(a+bD); fitted Δ10000 rate=10000/(T(D+10000)-T(D)). Loopback TTFT includes request overhead and first token. Server metric deltas and raw SSE are in JSON; residuals above 10% or nonphysical fits are not usable.

| Configuration | a (s/token) | b (s/token²) | Max relative residual | Usable | Error |
|---|---:|---:|---:|---|---|
| fp8-default | 3.6552818851518125e-05 | 3.1625850400471867e-10 | 0.029503171764773784 | True |  |

fp8-default residuals: `[{"length": 16384, "observed_s": 0.6598155559622683, "fitted_s": 0.6413288819314652, "residual_s": 0.018486674030803063, "relative": 0.028017942080559598}, {"length": 16384, "observed_s": 0.6608253250014968, "fitted_s": 0.6413288819314652, "residual_s": 0.01949644307003162, "relative": 0.029503171764773784}, {"length": 65536, "observed_s": 3.084341021021828, "fitted_s": 3.0746855021441677, "residual_s": 0.009655518877660363, "relative": 0.003130496534543879}, {"length": 65536, "observed_s": 3.0882522130268626, "fitted_s": 3.0746855021441677, "residual_s": 0.013566710882694899, "relative": 0.004393006123485579}, {"length": 131072, "observed_s": 7.481742741016205, "fitted_s": 7.507690936070487, "residual_s": -0.025948195054281697, "relative": -0.0034682019888266423}, {"length": 131072, "observed_s": 7.506210050021764, "fitted_s": 7.507690936070487, "residual_s": -0.0014808860487232067, "relative": -0.0001972881172861547}, {"length": 249000, "observed_s": 18.9145487670321, "fitted_s": 18.905823647426296, "residual_s": 0.008725119605808018, "relative": 0.0004612914488880553}, {"length": 249000, "observed_s": 18.902925745001994, "fitted_s": 18.905823647426296, "residual_s": -0.0028979024242996587, "relative": -0.00015330443886792897}]`

| Depth | Fitted marginal tok/s | Fitted Δ10000 tok/s | llama.cpp Δ10000 tok/s |
|---:|---:|---:|---:|
| 16000 | 24030.977901674316 | 23151.23099413969 | 2141 |
| 50000 | 19096.45357109184 | 18536.699391624214 | 1476 |
| 100000 | 14667.344067746117 | 14334.870240728567 | 1018 |
| 150000 | 11905.953286418393 | 11685.944408119485 | 780 |
| 200000 | 10019.58632216445 | 9863.313007728557 | 631 |
| 249000 | 8672.937648497447 | 8555.60225688923 | 532 |

Method B fp8-default

tok/s = Δ/TTFT; processed tok/s = (D+Δ-cached_tokens)/TTFT. Partial hits require D-block < cached_tokens <= D; without a known block only exact hits are accepted.

| D | Δ | cached_tokens | Status | tok/s | processed tokens | processed tok/s | block | gap | block source |
|---:|---:|---:|---|---:|---:|---:|---:|---:|---|
| 16384 | 2000 | 15680 | accepted | 11637.514965213917 | 2704 | 15733.920232969216 | 784 | 704 | server log: block_size |
| 16384 | 10000 | 15680 | accepted | 20140.264129906103 | 10704 | 21558.138724651493 | 784 | 704 | server log: block_size |
| 65536 | 2000 | 65072 | accepted | 8754.903267092715 | 2464 | 10786.040825058226 | 784 | 464 | server log: block_size |
| 65536 | 10000 | 65072 | accepted | 14767.621914088271 | 10464 | 15452.839570901968 | 784 | 464 | server log: block_size |
| 131072 | 2000 | 130928 | accepted | 7251.484510794928 | 2144 | 7773.591395572163 | 784 | 144 | server log: block_size |
| 131072 | 10000 | 130928 | accepted | 11184.678583331191 | 10144 | 11345.73795493116 | 784 | 144 | server log: block_size |
| 249000 | 2000 | 248528 | accepted | 4133.511000030511 | 2472 | 5109.019596037712 | 784 | 472 | server log: block_size |
| 249000 | 10000 | 248528 | accepted | 6987.3830533993605 | 10472 | 7317.18753351981 | 784 | 472 | server log: block_size |
| fp8-kv | 3.7657540487158585e-05 | 1.6236251049616915e-10 | 0.013167420357226838 | True |  |

fp8-kv residuals: `[{"length": 16384, "observed_s": 0.6472962929983623, "fitted_s": 0.6387730706127782, "residual_s": 0.008523222385584103, "relative": 0.013167420357226838}, {"length": 16384, "observed_s": 0.6427137039718218, "fitted_s": 0.6387730706127782, "residual_s": 0.0039406333590435855, "relative": 0.0061312421606873856}, {"length": 65536, "observed_s": 2.810268217988778, "fitted_s": 2.816595409705177, "residual_s": -0.006327191716398728, "relative": -0.0022514547458131608}, {"length": 65536, "observed_s": 2.8234089789912105, "fitted_s": 2.816595409705177, "residual_s": 0.006813569286033827, "relative": 0.002413242054811443}, {"length": 131072, "observed_s": 6.325695962004829, "fitted_s": 6.3305324920878565, "residual_s": -0.004836530083027313, "relative": -0.0007645846578902681}, {"length": 131072, "observed_s": 6.331917527015321, "fitted_s": 6.3305324920878565, "residual_s": 0.0013850349274644458, "relative": 0.00021873862405111117}, {"length": 249000, "observed_s": 14.397481920022983, "fitted_s": 14.410046587938979, "residual_s": -0.01256466791599653, "relative": -0.0008726989890171346}, {"length": 249000, "observed_s": 14.423479976016097, "fitted_s": 14.410046587938979, "residual_s": 0.013433388077117137, "relative": 0.000931355546612515}]`

| Depth | Fitted marginal tok/s | Fitted Δ10000 tok/s | llama.cpp Δ10000 tok/s |
|---:|---:|---:|---:|
| 16000 | 24841.42436075438 | 24350.360857627442 | 2141 |
| 50000 | 21845.667952456923 | 21464.995119163326 | 1476 |
| 100000 | 18555.01295205089 | 18279.662872718196 | 1018 |
| 150000 | 16125.932681727954 | 15917.552271142506 | 780 |
| 200000 | 14259.224194368786 | 14096.050886214285 | 631 |
| 249000 | 12806.424833644482 | 12674.65385404191 | 532 |

Method B fp8-kv

tok/s = Δ/TTFT; processed tok/s = (D+Δ-cached_tokens)/TTFT. Partial hits require D-block < cached_tokens <= D; without a known block only exact hits are accepted.

| D | Δ | cached_tokens | Status | tok/s | processed tokens | processed tok/s | block | gap | block source |
|---:|---:|---:|---|---:|---:|---:|---:|---:|---|
| 16384 | 2000 | 15680 | accepted | 13761.097511728878 | 2704 | 18605.003835857442 | 1568 | 704 | server log: block_size |
| 16384 | 10000 | 15680 | accepted | 20961.226292827192 | 10704 | 22436.89662384223 | 1568 | 704 | server log: block_size |
| 65536 | 2000 | 64288 | accepted | 8104.900856731766 | 3248 | 13162.358991332389 | 1568 | 1248 | server log: block_size |
| 65536 | 10000 | 64288 | accepted | 16315.965113022085 | 11248 | 18352.197559127242 | 1568 | 1248 | server log: block_size |
| 131072 | 2000 | 130144 | accepted | 7354.213644480833 | 2928 | 10766.56877551994 | 1568 | 928 | server log: block_size |
| 131072 | 10000 | 130144 | accepted | 13421.272102667619 | 10928 | 14666.766153795175 | 1568 | 928 | server log: block_size |
| 249000 | 2000 | 247744 | accepted | 4562.701578264622 | 3256 | 7428.078169414805 | 1568 | 1256 | server log: block_size |
| 249000 | 10000 | 247744 | accepted | 9298.27227855264 | 11256 | 10466.13527673885 | 1568 | 1256 | server log: block_size |
| nvfp4-default | 1.5861161229842387e-05 | 3.184855482314731e-10 | 0.09766554829693708 | True |  |

nvfp4-default residuals: `[{"length": 16384, "observed_s": 0.33536974200978875, "fitted_s": 0.3026156722742004, "residual_s": 0.03275406973558835, "relative": 0.09766554829693708}, {"length": 16384, "observed_s": 0.3305024530272931, "fitted_s": 0.3026156722742004, "residual_s": 0.027886780753092685, "relative": 0.08437692518666352}, {"length": 65536, "observed_s": 1.7613500410225242, "fitted_s": 1.7234195693103544, "residual_s": 0.03793047171216979, "relative": 0.02153488564382685}, {"length": 65536, "observed_s": 1.7601180030032992, "fitted_s": 1.7234195693103544, "residual_s": 0.03669843369294479, "relative": 0.020849984847792047}, {"length": 131072, "observed_s": 4.7718085600063205, "fitted_s": 4.8147241525235165, "residual_s": -0.04291559251719601, "relative": -0.008993569624079632}, {"length": 131072, "observed_s": 4.784636618045624, "fitted_s": 4.8147241525235165, "residual_s": -0.03008753447789214, "relative": -0.006288363543516491}, {"length": 249000, "observed_s": 13.832301271962933, "fitted_s": 13.822640384180536, "residual_s": 0.009660887782397154, "relative": 0.0006984295376778028}, {"length": 249000, "observed_s": 13.827775665966328, "fitted_s": 13.822640384180536, "residual_s": 0.005135281785792145, "relative": 0.00037137439237110127}]`

| Depth | Fitted marginal tok/s | Fitted Δ10000 tok/s | llama.cpp Δ10000 tok/s |
|---:|---:|---:|---:|
| 16000 | 47716.912731312834 | 44347.1610770638 | 2141 |
| 50000 | 31460.94698523405 | 29959.97373043893 | 1476 |
| 100000 | 20960.091208451777 | 20283.09365562955 | 1018 |
| 150000 | 15714.871023407988 | 15331.21059709918 | 780 |
| 200000 | 12569.403394360896 | 12322.752817150558 | 631 |
| 249000 | 10508.168432631934 | 10335.223973425593 | 532 |

Method B nvfp4-default

tok/s = Δ/TTFT; processed tok/s = (D+Δ-cached_tokens)/TTFT. Partial hits require D-block < cached_tokens <= D; without a known block only exact hits are accepted.

| D | Δ | cached_tokens | Status | tok/s | processed tokens | processed tok/s | block | gap | block source |
|---:|---:|---:|---|---:|---:|---:|---:|---:|---|
| 16384 | 2000 | 15680 | accepted | 7797.705924500336 | 2704 | 10542.498409924454 | 784 | 704 | server log: block_size |
| 16384 | 10000 | 15680 | accepted | 27584.495288120164 | 10704 | 29526.443756403823 | 784 | 704 | server log: block_size |
| 65536 | 2000 | 65072 | accepted | 1575.6360581631955 | 2464 | 1941.1836236570568 | 784 | 464 | server log: block_size |
| 65536 | 10000 | 65072 | accepted | 17481.00011904326 | 10464 | 18292.118524566868 | 784 | 464 | server log: block_size |
| 131072 | 2000 | 130928 | accepted | 5801.354699948197 | 2144 | 6219.052238344467 | 784 | 144 | server log: block_size |
| 131072 | 10000 | 130928 | accepted | 12384.979334677399 | 10144 | 12563.323037096752 | 784 | 144 | server log: block_size |
| 249000 | 2000 | 248528 | accepted | 3970.3016668830446 | 2472 | 4907.292860267444 | 784 | 472 | server log: block_size |
| 249000 | 10000 | 248528 | accepted | 7570.207495398151 | 10472 | 7927.521289180944 | 784 | 472 | server log: block_size |
| fp8-large-batch | 3.8586579474154383e-05 | 3.6343868663728276e-10 | 0.020953304472957738 | True |  |

fp8-large-batch residuals: `[{"length": 16384, "observed_s": 0.6955566430115141, "fitted_s": 0.6809824328923054, "residual_s": 0.014574210119208626, "relative": 0.020953304472957738}, {"length": 16384, "observed_s": 0.6908088100026362, "fitted_s": 0.6809824328923054, "residual_s": 0.009826377110330693, "relative": 0.014224452508492465}, {"length": 65536, "observed_s": 3.3519392420421354, "fitted_s": 3.3092887090223426, "residual_s": 0.042650533019792936, "relative": 0.012724136668362916}, {"length": 65536, "observed_s": 3.3363947100006044, "fitted_s": 3.3092887090223426, "residual_s": 0.02710600097826188, "relative": 0.008124338795111256}, {"length": 131072, "observed_s": 8.144292797951493, "fitted_s": 8.179534691253007, "residual_s": -0.03524189330151328, "relative": -0.004327188888687494}, {"length": 131072, "observed_s": 8.154499108029995, "fitted_s": 8.179534691253007, "residual_s": -0.02503558322301158, "relative": -0.003070155860138392}, {"length": 249000, "observed_s": 20.91925131698372, "fitted_s": 20.874839294163525, "residual_s": 0.04441202282019319, "relative": 0.0021230216200011126}, {"length": 249000, "observed_s": 20.842191712989006, "fitted_s": 20.874839294163525, "residual_s": -0.03264758117451905, "relative": -0.0015664178520233471}]`

| Depth | Fitted marginal tok/s | Fitted Δ10000 tok/s | llama.cpp Δ10000 tok/s |
|---:|---:|---:|---:|
| 16000 | 22521.71171028821 | 21636.22109170335 | 2141 |
| 50000 | 17618.502193656146 | 17071.923620423593 | 1476 |
| 100000 | 13345.709586039817 | 13029.716347361504 | 1018 |
| 150000 | 10740.863697284498 | 10535.234597156455 | 780 |
| 200000 | 8986.799728304626 | 8842.39672742745 | 631 |
| 249000 | 7746.964766605513 | 7639.419060962804 | 532 |

Method B fp8-large-batch

tok/s = Δ/TTFT; processed tok/s = (D+Δ-cached_tokens)/TTFT. Partial hits require D-block < cached_tokens <= D; without a known block only exact hits are accepted.

| D | Δ | cached_tokens | Status | tok/s | processed tokens | processed tok/s | block | gap | block source |
|---:|---:|---:|---|---:|---:|---:|---:|---:|---|
| 16384 | 2000 | 15680 | accepted | 11801.865722247343 | 2704 | 15956.122456478408 | 784 | 704 | server log: block_size |
| 16384 | 10000 | 15680 | accepted | 20543.815587350393 | 10704 | 21990.100204699862 | 784 | 704 | server log: block_size |
| 65536 | 2000 | 65072 | accepted | 8645.443200408423 | 2464 | 10651.186022903175 | 784 | 464 | server log: block_size |
| 65536 | 10000 | 65072 | accepted | 14800.48086680512 | 10464 | 15487.223179024877 | 784 | 464 | server log: block_size |
| 131072 | 2000 | 130928 | accepted | 7241.904883231178 | 2144 | 7763.322034823823 | 784 | 144 | server log: block_size |
| 131072 | 10000 | 130928 | accepted | 11142.965792641484 | 10144 | 11303.424500055522 | 784 | 144 | server log: block_size |
| 249000 | 2000 | 248528 | accepted | 4235.270881340757 | 2472 | 5234.794809337175 | 784 | 472 | server log: block_size |
| 249000 | 10000 | 248528 | accepted | 6833.985848536976 | 10472 | 7156.549980587922 | 784 | 472 | server log: block_size |
