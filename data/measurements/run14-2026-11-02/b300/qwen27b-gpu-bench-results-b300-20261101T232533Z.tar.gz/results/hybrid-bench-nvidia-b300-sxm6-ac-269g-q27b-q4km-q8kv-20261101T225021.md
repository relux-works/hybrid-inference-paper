| depth | segment prefill tok/s | Δ512 prefill tok/s | Δ2000 prefill tok/s | Δ10000 prefill tok/s | decode tok/s (at depth) |
|---|---|---|---|---|---|
| 16k (cum. 0.2 min) | 1756.7 | 1657.7 | 1659.0 | 1663.1 | 79.58 |
| 50k (cum. 0.4 min) | 1580.4 | 1456.2 | 1474.5 | 1485.0 | 67.63 |
| 100k (cum. 0.8 min) | 1388.0 | 1231.5 | 1267.3 | 1284.2 | 54.81 |
| 150k (cum. 1.3 min) | 1211.5 | 1065.8 | 1109.7 | 1131.2 | 46.27 |
| 200k (cum. 1.9 min) | 1074.3 | 941.2 | 989.7 | 1010.2 | 40.09 |
| 249k (cum. 2.5 min) | 966.3 | 844.1 | 892.1 | 914.6 | 35.37 |
slot save at 16k: 714 MB = 43.6 KiB/token, 249.858 ms
slot save at 50k: 1899 MB = 37.1 KiB/token, 677.176 ms
slot save at 100k: 3641 MB = 35.6 KiB/token, 1284.948 ms
slot save at 150k: 5383 MB = 35.0 KiB/token, 1902.629 ms
slot save at 200k: 7126 MB = 34.8 KiB/token, 2510.758 ms
slot save at 249k: 8833 MB = 34.6 KiB/token, 3149.402 ms
