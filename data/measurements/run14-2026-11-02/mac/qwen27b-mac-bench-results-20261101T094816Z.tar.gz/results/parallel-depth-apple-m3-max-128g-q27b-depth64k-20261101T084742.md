# Parallel decode at depth 65536: apple-m3-max-128g-q27b-depth64k

parallel_depth 1.1; model 31629f53165ab6a7dad8c9847dcfd1fdf55829dac1e6e748f4a68581b0033d34; build b11087-c21284cdf; 128 tokens per stream.

One-time prefill of 65536 tokens: 125.1 tok/s.

| Streams | Aggregate decode, tok/s | Mean per stream, tok/s | Gain over one stream | Restore reused |
|---:|---:|---:|---:|---|
| 1 | 7.222 | 7.22 | 1.0 | True |
| 2 | 11.85 | 5.93 | 1.641 | True |
| 4 | 13.893 | 3.47 | 1.924 | True |
| 8 | 15.613 | 1.95 | 2.162 | True |
| 16 | 27.162 | 1.7 | 3.761 | True |
| 24 | 31.926 | 1.33 | 4.421 | True |

Aggregate: timed decode steps of all streams divided by the longest server decode interval. A round with restore_reused false re-read more than the suffix; treat its numbers with care.
