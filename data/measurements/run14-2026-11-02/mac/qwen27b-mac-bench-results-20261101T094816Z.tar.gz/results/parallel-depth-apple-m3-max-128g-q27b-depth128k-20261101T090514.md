# Parallel decode at depth 131072: apple-m3-max-128g-q27b-depth128k

parallel_depth 1.1; model 31629f53165ab6a7dad8c9847dcfd1fdf55829dac1e6e748f4a68581b0033d34; build b11087-c21284cdf; 128 tokens per stream.

One-time prefill of 131072 tokens: 64.9 tok/s.

| Streams | Aggregate decode, tok/s | Mean per stream, tok/s | Gain over one stream | Restore reused |
|---:|---:|---:|---:|---|
| 1 | 6.346 | 6.35 | 1.0 | True |
| 2 | 8.88 | 4.44 | 1.399 | True |
| 4 | 9.732 | 2.43 | 1.534 | True |
| 8 | 10.106 | 1.26 | 1.592 | True |
| 12 | 13.858 | 1.16 | 2.184 | True |

Aggregate: timed decode steps of all streams divided by the longest server decode interval. A round with restore_reused false re-read more than the suffix; treat its numbers with care.
