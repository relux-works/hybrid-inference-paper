# Parallel decode at depth 1040000: apple-m3-max-128g-q27b-maxctx1040k

parallel_depth 1.1; model 31629f53165ab6a7dad8c9847dcfd1fdf55829dac1e6e748f4a68581b0033d34; build b11087-c21284cdf; 128 tokens per stream.

| Streams | Aggregate decode, tok/s | Mean per stream, tok/s | Gain over one stream | Restore reused |
|---:|---:|---:|---:|---|
| 1 | 1.672 | 1.67 | 1.0 | True |
| 2 | 1.656 | 0.83 | 0.99 | True |

Aggregate: timed decode steps of all streams divided by the longest server decode interval. A round with restore_reused false re-read more than the suffix; treat its numbers with care.
