# Paper v5d8: engines 25 and 26, the two phases of a session, the end-to-end plan, the vLLM status (run hybrid-c-r21o-261105)

Continue from your r21n head `04c3e8de` (v5d7) on `paper-v5`. Since then the evidence has advanced a lot. Bring it all
into the paper in one pass. FACTS (`/home/agent/lanes/hybrid/.temp/paper-v2/FACTS.md`) is the source for every number;
the new blocks are named below.

## 1. Engines 25 and 26, both accepted

FACTS blocks «Engine run 25 ...» (r5x9) and «Engine run 26, the closed contour against internal inference» (r5x12).
Merge the accepted `engine-r25` and `engine-r26` outputs into the paper repository as you did for run 24. Leave every
accepted byte unchanged.
- **Fleet (run 25).**
  - The 4-node bound is retained-copy storage: 200 copies, 57 per node.
  - The 1/2/4-node sensitivity: expanded NVMe 19.95 / 32.38 / 57.23; all-RAM 23.47 / 39.42 / 71.31.
  - The honest label: the one-node rows are mostly retention and local-compute savings; a profitable offload appears
    only for combined s = 20% at light load.
  - Every proxy is unmeasured.
  - This is a sensitivity, not a new headline. Table 18 stays on run 24 unless you add the sensitivity next to it,
    clearly labelled.
- **Closed contour (run 26)**, the analyst's thesis you wrote in r21n, now with numbers:
  - Qwen at s = 100%: 4 / 2 / capacity shortfall; purchased 128 GB: 20 / 2; claude_deep 3 / none / none.
  - The mixed scheme: s20 none / 5 / 2; s50 8 / 3 / shortfall.
  - GLM on the Ultra projection: owned none / 346 / 68, purchased never, 0% offload, so local compute and not a prefill
    speedup.
  - The cloud-class floor: $674 bought and $2,219 rented at team 50, affordable from 34 and 111 people.
  - Replace the «awaits engine 26» placeholders.
- **Coverage (run 25 Part C):** fitted shares only (27.28% of call shapes, 20.52% of input, 27.38% of output,
  28.68% of Mac seconds). Raw per-call shares are unavailable.

## 2. The two phases of an agent session: a new result

FACTS blocks «Portion size by depth in the owner's logs» (dev-d r18) and «Owner-log provenance for the quantile
session» (r49e). The first-request statistics come from dev-b's r49g packet (`QUANTILE-PROVENANCE.md`): medians 34,002
/ 56,820 / 33,002 / 25,044 (combined / Claude / Codex / Muse).
- **Start:** a huge first request (system prompt, tools, project instructions, the first task), then file reads. Most
  large portions arrive here.
- **Deep work:** small increments. The p90 portion size by depth bin is 6,215 / 5,344 / 2,329 / 1,448. Large
  portions at 100-200k are rare (fitted, about 0.43%).
- **What this means for the hybrid,** as an interpretation of measured data:
  - **Time gain at the start.** On the M3 Max the first request alone takes minutes; the server takes seconds. The link
    then dominates: about 3.5 GB of KV for 100k tokens.
  - **Independence and money in the deep phase**, where the client mostly reads for itself.
  - **Recovery copies** of deep sessions can live on disk, which supports the 1-2 node fleet sensitivity.
  - This explains the 40-turn result without a speedup and the 0% offload of claude_deep on the M5 Max.
- **A rough start-phase budget,** labelled an estimate from measured rates:
  - The lifecycle session reaches about 100k context in 4 requests.
  - The PRO 6000 with vLLM FP8 prefills 8,122 tok/s at 16k and about 3,000-5,000 at 65-100k (FACTS vLLM rows): about
    15-25 s of GPU per new context.
  - The M3 Max takes about 6-9 min at about 200 tok/s average.
  - 13,169 streams over 233 active days is about 56.5 contexts a day, so about 20 min of PRO GPU a day per person at
    the owner's intensity.
  - Mark it as an estimate and put the arithmetic in the appendix.
- **Under «Перспективы»:** the session-migration hypothesis, as a direction only. Run the shallow phase entirely on the
  server, where the batch decode gain is 15× at 16k, and hand over to the client as depth grows and the gain falls
  (2.2× at 164k).
- **Caveats:**
  - one owner's logs, mostly software development (an unquantified characterization);
  - portions exclude the first and reset calls;
  - the joint shares are fits.

## 3. The end-to-end measurement: the methods and the status (planned, not run)

- **The lifecycle quantile session as the stage-1 workload** (dev-b r49g `8432f75d`, under Muse r7be; if that review
  changes anything, the next pass follows it):
  - why not an average session;
  - the construction: the full lifecycle from zero, a median first request of 34,002, 116 requests to 228,388, large
    portions only where the data puts them;
  - the provenance: 1,524,671 calls in 13,169 streams, 2025-11-18 to 2026-10-30, 233 active days, Codex 73.7% /
    Claude 18.7% / Muse 7.6%, the domain per the owner;
  - the finite tail distortion (49.17% against 21.3% at 10k and above), disclosed;
  - the shared-prefix fairness rule (a 9,624-token synthetic invariant cache in both arms; the start gain counts only
    the varying part);
  - the per-phase breakdown;
  - the time-model check (predictions committed before the run, ±15%);
  - the limits.
- **The transport is qualified under the preregistration** (FACTS «End-to-end transport, tc/netem qualification after
  the fix»): 6 of 6 rows at 0.843-0.941. The first attempt failed at 1 of 6; say so in one sentence.
- **The preregistration is public:** prototype `m3-growing-r46`, draft PR relux-works/hybrid-inference#18.
- **Status:** no end-to-end result yet. The 40-turn statement is unchanged.

## 4. vLLM in a long session: the status

FACTS «vLLM long-session node, GPU qualification attempts on node V».
- Four attempts so far. Attempt 4 refused the predeclared quality gate at turn 1: KL 0.33 against a 0.03 bound.
- A diagnostic proved the server export byte-exact: 0 of 112 tensors differ from fresh cold and warm exports.
- The cause is downstream in the append import and is under investigation; the deadline is 2026-11-08 04:00Z.
- Until a passing receipt exists, the text says «vLLM в длинной сессии в работе», relies on the measured single-call
  bridge, and adds one sentence on what the gate caught.

## Rules

- Keep it short in the main text, with detail in the appendix. No new verbatim repetition between the introduction and
  the conclusion.
- The same gates and style rules as r21m and r21n. Both abstracts stay under their limits; mention the two-phase
  result there only if it fits naturally.
- CPU only. `TMPDIR` on disk, `PYTHONDONTWRITEBYTECODE=1`. agents1 free disk is at the **28 GiB** floor. Check
  `df -BG`; the engine merges are 13-18 MB of CSV each.
- Signed commits with the trailer `Co-authored-by: Codex gpt-6.1-sol <noreply@openai.com>`. No session links, no push,
  no tag.
- Send a short summary to `agents1_hybrid_orch` in #hybrid, topic prototype-go: the head, the PDF path, the counts, and
  what remains pending (RULER 128k and Holm, vLLM, the end-to-end run, the Mac calibration).
