# Review: engine run 25 (run hybrid-rev-r5x9-engine-r25-261105, Muse reviewer)

Verdict: **ACCEPT**
Candidate bound: `ec28e37c58f49e7109178d1c23334c4c7e0aad38` (branch `engine-r25`, parent `ca7f228a`), signed (`%G?` = G).
Method: `git clone --shared` of dev-e's checkout, CPU only, `PYTHONDONTWRITEBYTECODE=1`, TMPDIR on disk. Clone deleted after review. Disk stayed at 29 GiB free.

## Findings array

```json
{
  "findings": [],
  "notes": [
    {"id": "sensitivity-storage-excludes-gpu-slots", "row": "A-fleet",
     "note": "Accepted bound counts 54 NVMe + 3 GPU copies/node (ceil(200/57)=4). The run-25 sensitivity storage() counts only off-GPU copies (54/node inherited, 218/node expanded), so its inherited minimum is ceil(200/54)=4 by a stricter route. Disclosed in code comment and test name; conservative; no price or crossing changes. Not blocking."},
    {"id": "run16-tmpdir-must-be-in-repo", "row": "integrity",
     "note": "Parent test test_run16.test_data_only_replacement_rejects_unrecorded_sweep errors when TMPDIR is outside the repo (r16_audit.changed_cells does relative_to(ROOT)). Reproduced in my first full-suite run; passes with TMPDIR inside the repo, as in the producer's recorded gates. Harness-environment fact about pre-existing parent tests, not a run-25 defect."},
    {"id": "one-node-light-row-genuinely-offloads", "row": "A-fleet",
     "note": "Combined s=20% light on 1 expanded node is a real profitable_offload row (share 0.3076, x1; 0.2346 at x2slower IO). All other 1-node feasible rows are local_after_remote_queue_refusal or local_no_profitable_offload with share 0.0. CSV carries prefill_route per row; report labels zero-offload savings as retention/local-compute, not prefill gains (report sections 'Explicit unmeasured proxies', 'Reading the compact outputs', 'Changed crossings').Labelling is honest and complete."}
  ]
}
```

No blocking findings. Severity scale (bypass/regression/robustness/note): nothing at blocking severity; the three items above are notes.

## Surface results (brief checklist as rows)

| Row | Result | Evidence |
|---|---|---|
| A fleet bound | held | `storage_boxes` at `calc/hybridcalc/measurements_r20.py:99-103`, called before compute sizing in `hybrid` (`:181`); 249k reservation `calc/run23/engine.py:96`. Independent arithmetic: 249000×65536+156893184 = 16,475,357,184 B; floor(900e9/that)=54; slots(249000)=floor(61e9/copy)=3; 4×50=200; ceil(200/57)=4. $56.6446 = 4×614.0575/50+2.52+5 exactly. |
| A prices 1/2/4 | held | From `fleet_summary.csv` (team 50): expanded NVMe 19.948/32.376/57.231; all-RAM warm 23.468/39.416/71.311; inherited 4-node 56.645. Uplift recomputed: 400×0.8/48+400×0.02/12 = 7.3333/node-month; 10000 → 183.3333. Unit month 614.0575 in every row. |
| A shortfall refusal | held | Direct attacks through `Fleet.evaluate`: inherited 1 and 2 nodes at team 50 → `storage_shortfall`, no finite cost (146 copies short at 1 node); expanded team 500: 1 and 9 nodes refuse, 10 feasible (218×10 ≥ 2000); demand 10^6 on 1 node → `latency_or_compute_shortfall`, empty cost; rental billing → `InputGap run25.billing`; sub-copy NVMe → `InputGap run25.storage` from `minimum()`. CSV audit: 0 shortfall rows carry a finite cost; 0 feasible rows violate actual_queue ≤ charged_queue or the 70% occupancy cap. |
| A unmeasured + ×2 | held | All 576 fleet rows carry one of 3 `proxy_basis` strings, each starting UNMEASURED; `restore_slowdown` ∈ {1,2} everywhere; code multiplies read AND write bytes by the speed factor (`model.py`, Fleet init); ×2 moves the light 1-node offload share 0.3076 → 0.2346. Arrival, queue and serialization assumptions are labelled unmeasured in `config.json` bases and in the report. |
| B closed contour s=100% | held | Recomputed two ways. (1) CSV-internal: `sustained_from` re-derived from `cheaper_team_intervals` for all 24 `closed_contour.csv` rows and all 7,488 `crossings.csv` rows: 0 mismatches; team-50 hybrid<own consistency holds. (2) Through the engine: `engine.setup()` + accepted run-24 canonical series vs fresh `econ.own` at teams 1,2,3,4,5,50,500 — combined light first win at 4, medium at 2, heavy no win at any sampled team; claude_deep 3 / 1 / none. Matches report. Own cluster is the same `pro6000_fp8` server/billing via the accepted `own()`; uniform-weight equivalence is itself under a named test. s=20% rows carry the segment statement in the CSV `contour` column ("remaining 80% sent to stronger cloud model, not a closed contour") and in the report. |
| C coverage | held | `coverage.csv`: observed-log share columns blank; fitted shares 27.28% shapes (10885/39904), 20.52% input, 27.38% output, 28.68% Mac work seconds (combined) — re-derived from the CSV fields (0.27278/0.20517/0.27376/0.28683). `source_gap` and `work_proxy` state raw per-call shares are unavailable and the work denominator is modelled. Reweighting sensitivity is reported including its material adverse case (claude_deep s=100% medium loses the sustained crossing). |
| Integrity | held | `git diff --name-status ca7f228a ec28e37c`: 24 files, all additions, 25,522 insertions, 0 deletions; parent tree has 1,963 files, 1,062 under `calc/out` — all byte-identical by construction. New CSVs total 17,792,462 bytes (matches manifest and report). All 11 `calc/out/run25/manifest.json` SHA-256 entries re-verified. Commit is signed. |

## Tests rerun by the reviewer

- Kit: `unittest discover -s bench/tests` → 24 tests, OK.
- Engine: all 580 cases (562 historical + 18 run-25), 0 failures, 0 errors, 0 skipped, run per-module batches in the clone (137 + 79 + 154 + 111 + 81 individually-run modules + 18 run-25 = 580). First monolithic run showed 1 error, isolated to the parent `test_run16` TMPDIR-outside-repo artifact above; rerun with the producer's in-repo TMPDIR convention passes (21/21). This matches the producer's recorded gate environment in `calc/R25-VALIDATION-261105.json`.
- Mutants (mine, by monkeypatch narrowing, named test must fail; unmutated control passes 18/18):
  - queue: `mg1` forced to zero delay → `test_unstable_queue_cannot_report_zero_delay_with_analytic_control` FAILED as required.
  - storage: `storage()` forced feasible → `test_too_small_storage_refuses_with_expanded_positive_control` FAILED as required.
  - local: `Fleet.route` forced always-local → `test_queue_refusal_uses_local_capacity_without_dropping_overflow` FAILED as required.
  No surviving mutants, agreeing with the producer's 3 recorded mutant receipts.

## Free hunt

Beyond the checklist: rental-billing reuse of the office proxy (refused), sub-copy storage tier (refused), queue at ρ=1 (infinite delay, never certified), team-500 storage boundary at 9 vs 10 expanded nodes (exact), shortfall rows leaking finite prices into CSVs (none), certified rows exceeding charged queue or 70% occupancy (none), manifest hash drift (none), report-vs-CSV team-50 cells for the closed contour (all match). Nothing reproduced.

## Verdict

ACCEPT for `ec28e37c`. Run 25 answers both RC4-candidate reviews without touching accepted run-24 bytes: the 4-node fleet is a retained-copy storage bound, a 1-node light-load price near $19.95 exists only under declared unmeasured expanded-storage/restore proxies and is mostly a retention saving; the closed contour at s=100% crosses at 4/2/never (combined) and 3/1/never (claude_deep) against the same bought PRO cluster; coverage shares are fitted estimates with observed shares explicitly unknown.
