- **Portion size by depth in the owner's logs (dev-d r18, branch `m3-portion-depth` `74190ceb`,
  `tools/hybrid-eval/PORTION-DEPTH.md`; review pending).** These are the two phases of an agent session.
  - **Observed.** 1,505,761 portions; depth bins <50k / 50-100k / 100-200k / ≥200k hold 93,596 / 359,291 / 728,595 /
    324,279. Combined p90 portion size per bin: 6,215 / 5,344 / 2,329 / 1,448 tokens.
  - **Global incoming-volume shares,** observed and source-rounded: portions of 10k and more carry 21.3%, 30k and more
    4.2%.
  - **Fitted diagnostics, not empirical joint counts.**
    - At 100-200k, P(portion ≥ 10k) = 0.434957%.
    - The share of all incoming volume arriving at depth ≥ 100k in portions of ≥2k / ≥5k / ≥10k is 37.025% / 21.192% /
      4.780%.
    - Pooling the separate environment fits gives 4.999% against 4.780%: the result is sensitive to the dependence
      model.
    - The fitted Claude and Muse global ≥10k count shares, 0.782% and 0.662%, conflict with their observed p99 (above
      10k). They are flagged and must not be quoted as frequencies.
  - **Definitions.** Depth is measured after the addition. Portions are context-growth estimates that exclude the first
    call and reset calls, so the large first request is not among them. They are not exact prefill traffic.
  - **The first request** (analyst, from the logs; to be verified in dev-b r49g): median about 34k tokens; Claude Code
    about 57k, Codex about 33k, Muse about 25k.
  - **Contexts per day:** 13,169 streams over 233 active days ≈ 56.5, subagents included.
  - **Not computed:** a break-even table by depth bin. The accepted stateful policy needs the joint
    depth/portion/output/tier/pending-work state.

