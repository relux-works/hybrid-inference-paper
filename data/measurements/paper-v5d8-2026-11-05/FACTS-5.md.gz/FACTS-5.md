- **End-to-end transport, preregistered tc/netem qualification (2026-11-05 ~18:12Z): UNQUALIFIED, 1 of 6 rows.**
  - **Setup.** The infra manager ran dev-b's six-grid runner at prototype head `c2df294e` as root on a KVM VM:
    relux-tc-test on rise2, 4 vCPU, 8 GiB, kernel 7.0.0-38, Ubuntu 26.04. The link was shaped with netem inside network
    namespaces. The transport was 8 certificate-pinned HTTPS range connections. The threshold was at least 80% of the
    shaped rate.
  - **Results:**

    | Rate | RTT 50 ms | RTT 100 ms | RTT 150 ms |
    |---|---|---|---|
    | 15 MB/s | 0.814 | 0.543 | 0.439 |
    | 20 MB/s | 0.637 | 0.438 | 0.377 |

  - **Evidence.** Exit 3, `namespace_exit 3`. RESULTS.json sha256 baca55da...; tarball 7c3db216... in #lobby, topic
    hybrid-tc-qualification-261105.
  - **Reading.** Efficiency falls with RTT, so the transport is limited by the bandwidth-delay product. On the owner's
    iPhone path (about 19-28 MB/s at 46-50 ms) it would reach about 0.64. No end-to-end inference may start until a
    fixed transport qualifies (dev-b r49f).
