- **Engine run 25 (dev-e r20, `engine-r25` `ec28e37c`, parent `ca7f228a`; Muse r5x9 ACCEPT, 2026-11-05 ~18:48Z).**
  Report `calc/ENGINE-REPORT-R25-261105.md`.
  - **Basis.** Team 50, s = 20%, bought PRO 6000 with vLLM, Qwen, bf16 transport, owned M5 Max 64 at PRI 31, office
    link 125 MB/s at RTT 1 ms. Same measured-shape intensities as run 24.
  - **Why 4 nodes.** The fleet is sized by retained-copy storage, not compute.
    - 200 retained session copies of 16,475,357,184 B.
    - A node with 900 GB NVMe holds 54 copies, plus 3 in GPU memory: ceil(200/57) = 4.
    - Light-load compute alone uses 4,163 GPU-seconds a day, against 20,160 per node.
    - claude_deep pays retention even at 0% offload.
  - **Fleet sensitivity**, USD per person-month at 1 / 2 / 4 nodes, the same at light, medium and heavy load, for both
    the combined profile and claude_deep:
    - inherited 900 GB NVMe: storage shortfall / storage shortfall / 56.64;
    - expanded NVMe (3.6 TB, 7 GB/s, extra $400 capex per node): 19.95 / 32.38 / 57.23;
    - all-RAM warm (3.6 TB, 50 GB/s, extra $10,000 capex): 23.47 / 39.42 / 71.31.
  - **The one-node rows.**
    - They count as profitable offload only for the combined profile at s = 20%, light load.
    - Elsewhere they are savings from retention and local prefill after a queue refusal, not prefill gains.
    - Every restore, upgrade, arrival and queue input is unmeasured, with ×2 slower sensitivities in the outputs.
    - Bounds: mean queue at most 5 s and node reservation at most 70%. These are proxy bounds; there is no measured
      tail guarantee.
  - **Closed contour at s = 100%**, hybrid against the same bought PRO vLLM cluster. Crossings in team size through 500
    (light / medium / heavy):
    - combined profile: 4 / 2 / none;
    - claude_deep: 3 / 1 / none.
    - The s = 20% thresholds describe a segment in which 80% of calls go to a stronger cloud model. Reweighting by
      delta or output leaves the combined crossings unchanged. At s = 20%, claude_deep light 13 → 10 and medium 4 → 3;
      at s = 100%, medium loses the comparison under capacity bounds.
  - **Coverage: fitted shares, not observed** (raw per-call logs unavailable).
    - Combined profile: 27.28% of call shapes, 20.52% of input tokens, 27.38% of output tokens, 28.68% of Mac
      prefill-plus-decode seconds.
    - claude_deep: 55.4%, 24.88%, 45.58%, 29.43%.
  - **Integrity.** All 1,963 parent files and 1,062 historical outputs byte-identical. 580 engine cases (562 + 18 new)
    and the kit's 24 pass. CSVs 17,792,462 B.
