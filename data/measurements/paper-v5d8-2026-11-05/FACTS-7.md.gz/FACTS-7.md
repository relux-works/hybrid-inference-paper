- **vLLM long-session node, GPU qualification attempts on node V (Vast 59296672, RTX PRO 6000 Server, vLLM 0.32.0,
  torch 2.13.0+cu130), 2026-11-05.** Every input check passed in every attempt: the signature, the wheel, the 68 pinned
  FP8 shards, the Q4 GGUF and the native build. No attempt qualified.

  | Attempt | Head | Stopped at | Cause |
  |---|---|---|---|
  | 1 | `d110a119` | the CPU suite | a `/proc` race in one test; fixed in `09b1864f`, Muse r5x8 ACCEPT |
  | 2 | `d110a119` | vLLM readiness | the node lacked the snapshot's processor and tokenizer files (orchestrator setup); fixed by fetching the full revision `017b9c7a`, 81 files, with the pinned 68 re-verified |
  | 3 | `09b1864f` | the endpoint oracle | «warm single-token running-state route was not exercised»: `cached_tokens` ≠ end−1; the oracle conflated the final one-token forward with whole-request residency (receipts: prime 1,568, final cached 784, replayed 784, then 1,568 + 1 → 1,569); fixed in `fd92079f`, Muse r5x10 ACCEPT |
  | 4 | `fd92079f` | the quality gate at turn 1 | FP8-Q4-SESSION-KL-1 refused at depth 16,384 → prompt 22,385 (cached 15,680, replayed 704): mean KL 0.3286 nats (bound 0.03), matched partition 0.00174, excess 0.3269 (bound 0.025), top-1 51/64 (bound 60). An order of magnitude worse than the measured single-call bridge (0.020-0.026), so a session-path defect is suspected; dev-a r42d is investigating |

  The deadline is 2026-11-08 04:00Z. Without a passing receipt, the paper says «vLLM in a long session is in
  progress».

