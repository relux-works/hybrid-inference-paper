# Lifecycle session comparison and provenance

The frozen artifact is one116-request construction, not a sampled or median-length real session. No inference was used. Its final depth is228388; the log median/p75/p90 final depths are128571/191847/241714.4. Context262144 includes2048 reserve. The116 calls are the engine's estimated normalization group, versus37 observed median calls/stream.

| Environment | First requests (streams) | First-prompt median | Mean | p10 | Invariant-token bound | Bound / median |
|---|---:|---:|---:|---:|---:|---:|
| all | 13169 | 34002 | 37508.2 | 11175 | 0..9624 | 0..28.30% |
| claude | 2867 | 56820 | 66382.7 | 38599.6 | 0..38599.6 | 0..67.93% |
| codex | 7664 | 33002 | 30792.3 | 16259.2 | 0..16259.2 | 0..49.27% |
| muse | 2638 | 25044 | 25638.4 | 9624 | 0..9624 | 0..38.43% |

A length quantile gives only a loose upper bound on an everywhere-shared prefix. It establishes no common token identity or positive invariant fraction. The pooled p10=11175 is a loose bound; the combined everywhere-shared bound is tightened to9624 by the minimum environment p10 (Muse). This is not an estimate of average environment-specific cache benefit. The primary synthetic cache scenario is9624/34002=28.3042%, leaving24378 varying first-request tokens. It is an upper-bound scenario, NOT a measured cache share. Per-environment bounds are not fractions that can be averaged into the combined median. Actual system/tool prefix identity is unavailable. Both A.client and C.client restore the SAME Mac native fixture; C.node restores its own exact native fixture on the SAME prefix IDs. Preparation/restore are outside timing and separately charged.

| Continuation threshold | Session count /115 | Session token-volume share | Log token-volume share |
|---|---:|---:|---:|
| >=2000 | 13 (11.30%) | 77.87% | 75.60% |
| >=5000 | 5 (4.35%) | 57.72% | 51.10% |
| >=10000 | 3 (2.61%) | 49.17% | 21.30% |
| >=30000 | 1 (0.87%) | 25.60% | 4.20% |

The first34002-token request is excluded from this continuation table, as first calls are excluded from the source new_in distribution. The rare tail is distorted by a single finite session: one30k+ continuation dominates volume. It was not inserted or scaled to match a target share. Exact observed threshold COUNT shares are absent from the aggregates; source volume shares do not supply them.

| Previous-depth bin | Synthetic portions | Mean new tokens | Log portions | Log mean new tokens | Synthetic >=10k |
|---|---:|---:|---:|---:|---:|
| <50k | 1 | 34799.00 | 93596 | 1864.2 | 1 |
| 50-100k | 2 | 16018.50 | 359291 | 1547.8 | 2 |
| 100-200k | 50 | 1326.86 | 728595 | 876.7 | 0 |
| 200k+ | 62 | 44.15 | 324279 | 729.2 | 0 |

Source bins use current logged prompt depth; the engine reconstruction selects from previous depth. The fitted100-200k probability of a >=10k portion is0.4350%; this is a model result, not an observed0.4% frequency. Decreasing depth-conditioned means support smaller portions at depth; the aggregates do not establish a chronological burst law. Descending midpoint ranks impose large-first chronology explicitly.

| Metric | Frozen session | Combined logs |
|---|---:|---:|
| Output tokens, mean | 58470, 504.05 | mean511.9 |
| Output p50 /p90 | 226.50 / 1100.50 | 229 /1135 |
| Constructed wait p50 /p90 (s) | 7.80 / 34.41 | call gaps7.8 /34.8 |
| Constructed wait mean /total (s) | 29.16 / 3353.665316 | gap mean129.7; no tool-time total |

Waits are a p99-capped call-gap proxy, not tool time. Source p99=340s; its unknown long tail drives mean129.7 and is NOT reproduced. Claude-only p50/p90=8.1/60.6 must not replace combined values. Output anchors and mean are preserved by the declared monotone curve; endpoint16000 is an assumed engine cap. Finite midpoint means differ. No joint dependence between input/output/wait is claimed.

| Phase | Requests | Timed input tokens | Output tokens | Frozen waits (s) |
|---|---|---:|---:|---:|
| start | 1-4 | 91214 | 919 | 33.307826 |
| deep | 5-116 | 69080 | 57551 | 3320.357490 |

First-request TTFT is reported separately. Midpoint/end quality requests58/116 remain64-position checks. Checkpoint58 has340s following wait; capture budget30s. Overrun invalidates the series without reroll; end checks are deferred.

The full04 fit rests on1524671 calls in13169 usage-bearing streams, not proved distinct owner sessions. First-request n=13169; output n=1524671; new_in n=1505761; call gaps n=1511502. Prompt/output totals are250712809698/780505163; prompt totals include repeated context. The embedded historical_r49e_source_population_audit JSON (its old unfrozen status is historical) preserves per-environment shares and all subset unknowns. Exact per-depth session/token/date totals are unavailable. Full04 date coverage is unavailable.

Separately, full05 has13175 streams /233 active UTC dates =56.5451 streams per active day (1528194 calls,2025-11-18..2026-10-30;342276 timestamp conflicts). This is a corpus density, NOT observed new-context arrivals per day.13169/233 splices different snapshots. Subagents may be separate streams; this is not owner task/project count.

Domain: the owner characterizes the corpus as mostly writing/designing codebases; the share is unquantified because aggregate exports have no project, repository or task metadata. Public llama.cpp text does not classify the owner history.

## Mac budget (planning only)

| Link MB/s | A timed h | A wall h | C timed h | C checker h | C wall h | A-C pair h |
|---|---:|---:|---:|---:|---:|---:|
| 18.75 | 3.33 | 3.46 | 3.08 | 1.67 | 4.87 | 8.33 |
| 27.875 | 3.33 | 3.46 | 3.03 | 1.67 | 4.83 | 8.28 |
| 100 | 3.33 | 3.46 | 2.95 | 1.67 | 4.75 | 8.21 |

Zero-cache sensitivity is arithmetic only on the same IDs; it adds prefix computation to both arms and does not authorize an extra inference arm. At18.75MB/s, A/C timed hours are 3.349/3.090 versus 3.334/3.082 with the declared9624-token cache. The zero-cache vs upper-bound cache comparison is a sensitivity bound, not an identified deployment cache benefit.

Planning, NOT dev-e preregistered predictions. Step512 delta rates extrapolate beyond measured sizes; server1097 is a surrogate. Background assumes all previous catch-up hidden. Native state load cost unknown. Cold process startup, one-time cache creation, real restore/probe overhead and qualification excluded from these arm walls; reserve separately. Envelope estimates omit extra state copies from native chunking, journal upload, TLS and control. Two checker fills plus60s each are a lower planning model; actual checkpoint checker can run more references. Unscaled fill bracket retained. Actual public rehearsal controls admission; do not promise2-3h or weaken quality to fit it.

The analyst's2-3h expectation is not supported for this exact116-request file once55.9min of fixed waits,58,470 decoded tokens and deferred quality references are included. Do not shorten waits/responses or weaken gates to meet that expectation. A-C-A-C doubles the paired reservation. Qualify/probe, cache creation/restore, cold start and r47 cooldown must be measured separately.

## Pinned sources

Paths below are relative to the read-only paper repository. The moving paper head is not the data identity. Original r49d/r49e and original preregistration bytes remain unchanged.

| Source | SHA256 |
|---|---|
| `data/measurements/ivmbp-2026-10-30/stats.json` | `8c5f1f2c44e344b78d32d0b4c216d0ebdf2ecdae3cde0f1a983cb329e488e2a7` |
| `calc/hybridcalc/data/measurements.json` | `ad166373a9ccbda070d5fdf86bb513049b5b1cc6f01dda8a11538dad9e557804` |
| `calc/hybridcalc/data/workload.json` | `33604c9f7296145a5b054f0674fd2ef201852b626b920e2b5962809346ea524e` |
| `calc/hybridcalc/data/sampler.json` | `f1b36304bf6609ae0494621a1dd412eac88e89798b780ae0f2ce93c40a45ffa7` |
| `calc/hybridcalc/sampler_fit.py` | `274b0b18f8401edbcf93b4a82fa56e3595d999acae9336d792835b3c39e20c3b` |
| `calc/hybridcalc/workload.py` | `7a15a8b4ecdd9e7be2a80b3b5e593b0375107a7f0c99492f67ccc6c123ba70fd` |
| `calc/out/run23/workload_profiles.csv` | `d520de4aee5212f04590df1d57189402b653f92f8bdc456874b421cf6310a6e3` |
| `data/measurements/ivmbp-2026-10-30/agent_session_stats.py` | `6774541d434448893ad5827a95c0c13e98fe5139aa8b7647c533d34138ce7c3d` |
| `data/measurements/ivmbp-2026-10-30/README.md` | `62e56983df9fcb067733c26b8a0b93bfdc24132b31370ec8658618e8c48ac843` |
| `data/measurements/ivmbp-2026-10-30/REPORT.md` | `8f7393a2ea3c63077fa3b10b2525ad2ca41742273f3771b957aab65b2a2ef4d9` |
| `data/measurements/ivmbp-2026-10-30/MANIFEST.json` | `7eee07e337a6542ede2ba4e5ebc95042cbd105f0acfc63d81ba7f75d0459fb09` |
| `data/measurements/ivmbp-2026-10-30/session-call-dates/stats.json` | `13ef04258297f04b2661330da30843c6fe8fae048f66a2639ec8bf94967a8b3f` |
| `data/measurements/ivmbp-2026-10-30/session-call-dates/call-dates.json` | `9b85066011b501a89f0651fa7eafa3e23bca8558fd0af608b565fb3ce63fb481` |
| `data/measurements/ivmbp-2026-10-30/session-call-dates/REPORT.md` | `de4a537327b4240a9ccac7893f97b568bceff6bea2e1d57074641515bcf5f166` |
| `data/measurements/ivmbp-2026-10-30/session-call-dates/MANIFEST.json` | `3f4c87ec06f43c21afee55edd1700ffe9c3f56fbc22b8258da04e393f478d6ba` |
