- **Owner-log provenance for the quantile session (dev-b r49e `d99b5a91`, `QUANTILE-PROVENANCE.md`).**
  - Engine full04: 1,524,671 calls in 13,169 usage-bearing streams (parser contexts; the owner-session count is not
    recoverable), 250,712,809,698 logged input and 780,505,163 output tokens.
  - Portion observations 1,505,761: 93,596 below 50k depth, 359,291 at 50-100k, 728,595 at 100-200k, 324,279 at 200k
    and deeper.
  - Environments: overall Codex 73.66%, Claude 18.70%, Muse 7.64%. In the 100-200k bin: Codex 82.40%, Claude 12.30%,
    Muse 5.30%.
  - Dates (cohort full05): 2025-11-18 to 2026-10-30, 233 active UTC dates.
  - Call gaps: all environments 1,511,502 pairs, p50 / p90 7.8 / 34.8 s; Claude 282,262 pairs, 8.1 / 60.6 s. These are
    call gaps, not measured tool time.
  - Domain: software development (writing and designing codebases) per the owner's characterization. It is
    unquantified, because the exports carry no project metadata.
  - **At 100-200k depth, large portions are rare:** P(portion ≥ 10k) ≈ 0.00435. Across all depths, portions of 10k
    and more carry 21.3% of incoming volume, and 30k and more 4.2%. An 80-turn depth-conditioned quantile session from
    100k therefore contains no portion of 10k or more; its largest is 9,738.

