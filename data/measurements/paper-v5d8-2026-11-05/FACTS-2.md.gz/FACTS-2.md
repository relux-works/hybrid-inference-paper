- **Engine run 26, the closed contour against internal inference (dev-e r21/r21b, `engine-r26` `397432dd`, parent
  `ec28e37c`; Muse r5x12 ACCEPT, findings [], 2026-11-05 ~20:04Z).** Report `calc/ENGINE-REPORT-R26-261105.md`, tables
  `calc/out/run26/`.
  - **Primary basis.** Bought office server at 125 MB/s and 1 ms, s = 100%, bf16, the same-model own cluster. The
    contract is prefill only: the server never generates, and run 25's server-generation fallback is excluded.
    Crossings are sustained, through 500 people, light / medium / heavy.
  - **Qwen on the PRO, combined profile:**
    - owned M5 Max 64 or 128, and purchased 64: 4 / 2 / capacity shortfall;
    - purchased 128: 20 / 2 / shortfall.
  - **Qwen, claude_deep:** 3 / none / none. At medium and heavy load the client's capacity refuses.
  - **GLM-5.3-Flash on an M5 Ultra projection** (unmeasured; two B300 per replica, x1 prefill portability):
    - owned Studio 256/512: none / 346 / 68;
    - purchased: no sustained crossing;
    - claude_deep owned: none / 57 / none;
    - with ×2 slower GLM server prefill, owned medium / heavy: 197 / 63.
    - GLM at team 50 offloads 0% in every feasible row, so any GLM support is projected local compute or paid
      retention, not a prefill speedup.
  - **The mixed scheme.** The remainder (80% or 50%) runs on an internal large model whose common cost C is identical in
    both alternatives and cancels exactly in all 3,072 rows. Owned Max64 on the PRO:
    - s = 20%: none / 5 / 2;
    - s = 50%: 8 / 3 / shortfall.

    No task-quality parity is claimed.
  - **The cloud class inside the contour.** Qwen3.8-2.4T in FP8 needs at least 2× 8-B300 nodes by weights. Team-50
    capacity floor: $674.03 bought and $2,219.20 rented per person-month; within $1,000 from 34 (bought) and 111
    (rented) people. Service throughput, storage and interconnect are pending; this is a weights floor, not a serving
    load. The hybrid refuses the model (named negative).
  - **M5 Ultra** is taken as 2× the measured M5 Max compute and 2× inferred effective bandwidth (571-910 GB/s). Studio
    list-price proxies: $10,799 and $22,299 for 256 and 512 GB; Apple's configurations are sourced.
  - **Integrity.** All 1,987 parent files and 1,072 historical outputs byte-identical. 606 engine cases and the kit's
    24 pass in the reviewer's clean isolated rerun; an earlier polluted reviewer run is explained and retracted. 3
    mutants killed. CSVs 13,632,019 B.

