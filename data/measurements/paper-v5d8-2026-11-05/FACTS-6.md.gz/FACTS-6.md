- **End-to-end transport, tc/netem qualification after the fix (2026-11-05 ~19:50Z): QUALIFIED, 6 of 6 rows.**
  - **Head and review.** Prototype `a2c7591f` (dev-b r49f), accepted by Muse r7bd.
  - **The fix.** Bounded HTTP/1.1 connection reuse inside each transfer owner; 4 MiB TCP buffers set before connect and
    listen; 256 KiB reads; TCP_NODELAY; backlog 64 with admission 32. The cause had been 11 fresh TCP/TLS connections
    per 128 MiB probe with no buffer provisioning. Security gates are unchanged.
  - **Rerun.** On the same VM (relux-tc-test, rise2) with the same grid and the same 80% gate. Exit 0, no
    FAILED/BLOCKED receipt.
  - **Results:**

    | Rate | RTT 50 ms | RTT 100 ms | RTT 150 ms |
    |---|---|---|---|
    | 15 MB/s | 0.941 | 0.908 | 0.878 |
    | 20 MB/s | 0.918 | 0.881 | 0.843 |

  - **Evidence.** RESULTS.json sha256 e5e05b8b...; tarball 562a6b0d... in #lobby, topic
    hybrid-tc-qualification-261105. The infra manager verified the packet and commit signatures against reluxbot's
    GitHub signing key.
  - **Unshaped loopback:** 344.1 MB/s against 280.9 MB/s before the fix.
  - The failed `c2df294e` evidence is kept.

