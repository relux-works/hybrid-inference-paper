## 1. Server: RTX PRO 6000 Blackwell Workstation (96 GB, 600 W)

Setup for all rows: llama.cpp `c21284cd` built from source with CUDA 12.8, arch `120a-real`, `-ngl 999 -fa on -ctk q8_0
-ctv q8_0`; Qwen3.8-27B Q4_K_M (sha256 31629f53…3d34).
- **Reproduced base, checkpoints off.** Two runs agree within 0.355% (engine run 13 fit; archives fd0bc08c… and
  e80d4240… in `.temp/gpu-results-261101/`).

  | Depth | Δ512 | Δ2000 | Δ10000 | Decode |
  |---|---|---|---|---|
  | 16k | 3,509 | 3,547 | 3,435 | 61.8 tok/s |
  | 249k | 898 | 905 | 971 | 34.6 tok/s |

  Prefill columns are tok/s.
- **Server default checkpoints (A/B, archive 92828a6c…).** Decode is the same.

  | Depth | Δ512 | Δ2000 | Δ10000 |
  |---|---|---|---|
  | 16k | 1,600 | 2,876 | 3,263 |
  | 249k | 742 | 946 | 973 |

  Checkpoints cost mainly on short deltas.
- **The earlier series (run 12 basis, archive 9accab80…, same card model and commit) was slower.** Δ2000 was 2,147 at 16k
  and 533 at 249k, and decode was 15–30% lower. The checkpoint A/B does not explain it. In run 13 it is a sensitivity
  case.
- **FP8 fraction.** The effective model-FLOP fraction of the dense FP8 peak is 14.1–21.1% across depths, against 8–13%
  in the earlier series. Formula: `(54e9 + 393216·depth)/(a+b·depth)/peak`. It is not nvidia-smi utilisation.
- **llama-bench sweep (step 70).** The newer upstream build `dde879bc` is 9–20% faster than `c21284cd`; ubatch tuning
  adds 2–5%. pp4096 at depth 0: 3,950 tok/s (`c21284cd`, ubatch 4096), 4,793 tok/s (`dde879bc`, ubatch 512).
- **vLLM 0.32.0, Qwen3.8-27B-FP8, same card, server only.**
  - Cold prefill: 8,122 tok/s at 16k, 2,209 at 249k.
  - Prefix caching works in Mamba "align" mode with 784-token blocks.
  - Cached deltas, Δ2000/Δ10000: 5,370/7,144 at 16k; 3,162/4,598 at 65k; 2,177/3,130 at 131k; 1,258/1,962 at 249k.
  - NVFP4 and FP8 KV did not start.
  - Not yet usable by our client: the state bridge is in qualification (pending).

- **vLLM decode batching by depth on the RTX PRO 6000 Workstation, measured (GPU kit 1.6.11 `cd85a194`, Muse r7at
  ACCEPT; Vast node G, New York; stage 2026-11-03 20:10:09-23:35:50Z, receipt status done, 3.43 h, $6.53).** vLLM
  0.32.0, Qwen3.8-27B-FP8, default KV (FP8 KV does not start on SM 12.0). Each stream has its own context with a private
  prefix and salt and generates 256 tokens. Three rounds, median aggregate over the common decode interval. Timing
  granularity: SSE chunk receipt, with exact token ids per chunk (vLLM merges queued tokens when the reader lags).
  Evidence: `.temp/evidence/vllm-pro-g1611-261103/` (g1611.tar.gz, sha256 8a58f122...efe0).

  | Depth | Largest resident | Aggregate tok/s at N = 1 / mid / max | Gain at max |
  |---|---|---|---|
  | 16,384 | 39 | 48.70 / 302.60 (8) / 737.93 (39) | x15.15 |
  | 65,536 | 12 | 44.46 / 190.29 (8) / 225.35 (12) | x5.07 |
  | 164,000 | 5 | 38.11 / - / 84.22 (5) | x2.21 |
  | 256,000 | 3 | 33.07 / - / 57.73 (3) | x1.75 |

  - The largest resident count falls with depth because each session's KV must stay resident; larger N are no-fit.
    At 16k, N = 32 gives 686.82 (x14.10).
  - Per-stream rate at the largest N: 18.92 / 18.78 / 16.84 / 19.24 tok/s.
  - TTFT median at the largest N: 2.55 / 1.37 / 0.61 / 0.97 s.
  - The kit 1.6.9 run's 16k rows (48.72 / 302.98 / 686.80 / 738.10) agree within 0.1%.
  - **1M on the PRO 6000 (step 74), refused as accepted outcome data:** default KV needs 61.97 GiB for 1,010,001 tokens,
    and 56.62 GiB is available. FP8 KV is unavailable.
  - **vLLM-to-client bridge timing (prototype `m3-vllm-bridge-timing` `82843cee`, loopback, CUDA client), medians:**
    - 16k, Δ2343: TTFT 1,710.6 ms. Server prefill 335.1, export 72.6, conversion 570.2, transfer 39.5, import 349.0,
      other and local tail 315.9.
    - 16k, Δ10000: TTFT 4,741.7 ms. Prefill 1,616.2, export 226.6, conversion 1,606.5, transfer 89.5, import 771.4,
      other 435.5.
    - Deeper rows: in `bridge/timing/bridge-timing.json`.

## 1a. Server: kit 1.6.5 on the PRO 6000, llama.cpp `dde879bc`, Q4_K_M, q8_0 KV (host2, 2026-11-02 02:48-03:09Z)

Archives in `.temp/kit165-host2/`:
- `qwen27b-gpu-bench-results-20261102T030926Z.tar.gz` (3364b8a1...fe5);
- `gemma31-...030127Z` (a8b38efb...dc602);
- `glimmer30-...024947Z` (a9c8887e...606c).

Columns: segment prefill / Δ512 / Δ2000 / Δ10000 in tok/s, then decode tok/s at depth.

| Model | 16k | 50k | 100k | 150k | 200k | 249k |
|---|---|---|---|---|---|---|
| Qwen3.8-27B | 4,295 / 3,876 / 3,909 / 3,778 / 63.8 | 3,241 / 2,653 / 2,716 / 2,657 / 57.3 | 2,255 / 1,807 / 1,767 / 1,888 / 49.6 | 1,699 / 1,382 / 1,345 / 1,477 / 43.5 | 1,365 / 1,111 / 1,097 / 1,214 / 38.4 | 1,144 / 950 / 925 / 1,035 / 34.5 |
| Gemma 4 31B (SWA) | 3,476 / 3,025 / 2,977 / 2,684 / 56.0 | 1,959 / 1,614 / 1,633 / 1,560 / 44.1 | 1,248 / 1,019 / 1,039 / 1,018 / 33.5 | 879 / 746 / 767 / 761 / 27.0 | 681 / 593 / 613 / 610 / 22.6 | 559 / 492 / 511 / 511 / 19.5 |
| Glimmer 30B (SWA) | 4,468 / 4,042 / 4,171 / 4,221 / 73.4 | 3,986 / 3,378 / 3,616 / 3,712 / 68.1 | 3,428 / 2,725 / 3,015 / 3,126 / 61.6 | | | 118k: 3,028 / 2,531 / 2,823 / 2,936 / 59.4 |

- Qwen on the new build against `c21284cd` (section 1): Δ2000 at 16k is 3,909 against 3,547 (+10%), at 249k 925
  against 905; decode 63.8 against 61.8 at 16k.
- SWA models now run on the GPU depth ladder.
- Re-reads: none. Every delta row in the three JSONL files (12 Glimmer, 18 Qwen, 18 Gemma) processed only its delta.

