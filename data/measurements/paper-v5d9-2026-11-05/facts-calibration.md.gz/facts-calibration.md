- **Mac partition-noise calibration at 524,288, PARTIAL (kit 1.6.13-cal `8008141f`, Muse r7bc ACCEPT; incident lane,
  M3 Max, 2026-11-05 20:47-20:59Z; cancelled by the owner during the cooldown before 1.04M, «пока давай квен
  калибровку отменим»).**
  - **Status.** Not a completed calibration: depth 1,040,000 never started, and 3.014 at 1.04M stays unexplained.
    Depth 524,288 finished 6 of 6 children; all guards passed (pageouts 597-1,385 pages against the 4,096 limit,
    swapouts 0). The host was not idle (load about 70), so the timings are not idle timings.
  - **At 524,288:**

    | Pair | max abs dlogit | Mean KL | Max KL | Top-1 |
    |---|---|---|---|---|
    | Metal against Metal, all pairs (512/512, 256/256, repeat; probe and delta690) | 0 | 0 | 0 | 64/64 |
    | CUDA against Metal, probe | 1.08298 | 0.000329 | 0.001754 | 64/64 |
    | CUDA against Metal, delta690 | 0.83727 | 0.000399 | 0.002281 | 64/64 |

    The three captures of each kind are byte-identical.
  - **Reading.** On Metal, the 512 and 256 partitions give bit-identical logits after the restored slot, so under the
    preregistered rule B(524288) = 0. The historical 1.08298 is reproduced exactly and is a CUDA-against-Metal
    difference, not Metal partition noise. In distribution it is negligible: KL 0.0003-0.0004, top-1 64/64.
  - **For the paper:** report KL, top-1 and max |Δlogit| with this decomposition. Do not call it a completed
    calibration, and do not use the word «прошёл».