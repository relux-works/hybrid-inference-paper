- **vLLM long-session node, GPU qualification attempts on node V (Vast 59296672, RTX PRO 6000 Server, vLLM 0.32.0,
  torch 2.13.0+cu130), 2026-11-05.** Every input check passed in every attempt: the signature, the wheel, the 68 pinned
  FP8 shards, the Q4 GGUF and the native build. No attempt qualified.

  | Attempt | Head | Stopped at | Cause |
  |---|---|---|---|
  | 1 | `d110a119` | the CPU suite | a `/proc` race in one test; fixed in `09b1864f`, Muse r5x8 ACCEPT |
  | 2 | `d110a119` | vLLM readiness | the node lacked the snapshot's processor and tokenizer files (orchestrator setup); fixed by fetching the full revision `017b9c7a`, 81 files, with the pinned 68 re-verified |
  | 3 | `09b1864f` | the endpoint oracle | «warm single-token running-state route was not exercised»: `cached_tokens` ≠ end−1; the oracle conflated the final one-token forward with whole-request residency (receipts: prime 1,568, final cached 784, replayed 784, then 1,568 + 1 → 1,569); fixed in `fd92079f`, Muse r5x10 ACCEPT |
  | 4 | `fd92079f` | the quality gate at turn 1 | FP8-Q4-SESSION-KL-1 refused at depth 16,384 → prompt 22,385 (cached 15,680, replayed 704): mean KL 0.3286 nats (bound 0.03), matched partition 0.00174, excess 0.3269 (bound 0.025), top-1 51/64 (bound 60). An order of magnitude worse than the measured single-call bridge (0.020-0.026), so a session-path defect is suspected; dev-a r42d is investigating |

  The deadline is 2026-11-08 04:00Z. Without a passing receipt, the paper says «vLLM in a long session is in
  progress».
  - **Diagnostics on node V after attempt 4** (2026-11-05; both reviewed: Muse r5x11 and r5x13; qualified=false
    throughout).
    - **Diagnostic 1** (`7708cc4d`): the original export against fresh cold and warm exports of the same prefix
      P[:22384], n0 16,384. 0 of 112 tensors differ (conv, recurrent and KV for every layer), so the server-side
      session path and cache route are excluded. An independent rescore confirms KL 0.328648 and 51/64.
    - **Diagnostic 2** (`3f158a27`).
      - Codec conversion excluded: the NumPy re-conversion is byte-exact in components and logits.
      - Append mechanics exact: server-prefix append equals a full-server import, byte for byte.
      - Under the unchanged gate at local tail 1, every arm refuses:

        | Arm | Mean KL | Top-1 |
        |---|---|---|
        | mixed (Q4 client prefix plus FP8 delta) | 0.3286 | 51/64 |
        | full-server prefix | 0.2649 | 53/64 |
        | partition | 0.0017 | 64/64 |

      - The first 5 positions after the sync point give KL 0.12 / 0.36 / 0.76 / 0.64 / 0.26, max |Δlogit| 14.9.
        **Correction (dev-a r42f):** the error is NOT confined to them. The remaining 59 mixed positions average KL
        0.320, max 2.23 at position 22417. The earlier «falls to 0.01-0.02» read only positions 5-7 and was wrong.
      - Local tail 434 (outside N-1, raw only): full-server 0.168, mixed 0.149, partition 0.0012.
    - **Reading.** The transport and the import are exact. The divergence is the FP8 server state against a Q4
      client's own computation, and the mixed prefix adds only about 0.06.
      - The historical all-server checkpoint `9348ecd6` (FP8-Q4) measured 0.020/0.023, but it is not comparable.
        dev-a r42f found that it used local tails 356/662 (against 1), depths 8,196/32,806 (against 22,385),
        hybrid-greedy teachers and KL(hybrid||local), against fixed teachers and KL(local||hybrid) now. Its prompt
        also repeated synthetic filler, which weakens the workload hypothesis.
    - **Diagnostic 3, natural text** (`b7e2b6d2`, Muse r5x15 ACCEPT; node V 21:3x-21:46Z; qualified=false).
      - Setup: one pinned public document (pg1342, «Pride and Prejudice», fixture sha256 930f8d2d...) at the same
        depth of 22,385, with the same N-1, teacher-64 and KL(local||hybrid).
      - Results under the unchanged FP8-Q4-SESSION-KL-1:
        - mixed: mean KL 0.00651, excess 0.00558, top-1 60/64, ACCEPTED;
        - full-server: KL 0.0085, excess 0.00757, top-1 58/64, refused on the top-1 bound only;
        - local partition control: KL 0.00093, top-1 62/64.
      - Reading:
        - The KL of 0.26-0.33 comes from the synthetic repeated-text qualification workload, not from the FP8-to-Q4
          handoff as such. On natural text the KL is 40-50 times smaller.
        - The top-1 bound of 60/64 sits close to the partition noise of 62/64.
        - This is one document, a diagnostic, not a qualification.
      - dev-a's conclusion (r42f `b7e2b6d2`): the codec and append controls are exact, but the N-1 handoff fails
        even with an all-server prefix. llama.cpp stays the qualified fallback. No universal impossibility is
        claimed. A natural-text diagnostic is proposed.
      - dev-a r42f is investigating. Without a qualified receipt, the llama.cpp same-format path, where Q8 to Q4 sits
        within partition noise, stays the qualified route.
