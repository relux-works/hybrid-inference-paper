- **Stage-1 time prediction, the pre-probe forecast (dev-e r22, `prediction-stage1` `38299293`, predictions.json
  96a91207...; Muse r5x14 ACCEPT, 2026-11-05 ~21:00Z).**
  - **Session** 11d517ff (lifecycle, 116 requests).
  - **Arm A**, local on the M3 Max at PRI 31: 13,084.935 s (3.63 h).
  - **Arm C**, hybrid with background catch-up, llama.cpp node on the PRO, bf16 state: 11,992.112 / 11,882.400 /
    11,790.457 s at 15 / 20 / 28 MB/s and 80 ms (3.33 / 3.30 / 3.28 h); office 11,769.066 s.
  - **Frozen waits:** 3,353.665 s, 26-28% of the total, so ±15% on the total is about ±20-21% on active time.
    Active-time and per-phase errors are reported as the primary diagnostics, and the preregistered ±15% criterion is
    kept.
  - **Before inference,** a second signed numeric commitment needs the adapter, the bf16 import fit, the policy and
    build receipts, and the qualified probe.
