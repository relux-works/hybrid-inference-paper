    - Glimmer 30B is dense: 52 layers, 39 sliding-window-2048 and 13 global (every fourth); Q/KV heads 32/2; head
      dimension 128; vocabulary 202,048; output scale 0.196116 with final-logit softcap 20; no MoE router.
    - Qwen3.8-27B is a dense hybrid: 16 attention and 48 recurrent layers.
    - Softcapping compressing the top-2 margins is a hypothesis. A GPU margin stage is prepared: 26 frozen 8k prompts
      per model, partitions 512 against 2048, about 15-30 GPU minutes.
